# Optional React component
Requires React 18+ and TypeScript/JSX in the consuming app. No icon-font dependency.
Copy ArohaIcon.tsx, then import { ArohaIcon } from './ArohaIcon'.
Decorative next to visible text: <ArohaIcon name="gardening" />
Meaningful standalone image: <ArohaIcon name="gardening" title="Gardening" />
Icon-only control: <button aria-label="Search"><ArohaIcon name="search" /></button>
Colour inherits from the parent. Use weight="strong" at compact sizes if needed.
The helper is a client component because it uses useId for unique accessible title IDs.
