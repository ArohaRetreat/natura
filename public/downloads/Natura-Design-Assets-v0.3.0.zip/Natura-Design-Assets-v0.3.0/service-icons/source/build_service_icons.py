"""Custom Aroha service/feature icon pack. Deterministic original SVG geometry."""
from pathlib import Path
import argparse, copy, csv, hashlib, io, json, shutil, zipfile
import xml.etree.ElementTree as ET
import cairosvg
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg

ap=argparse.ArgumentParser();ap.add_argument('--brand',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
OUT=a.output;OUT.mkdir(parents=True,exist_ok=True)
G='#163E2D';W='#FFFFFF';NS='http://www.w3.org/2000/svg';ET.register_namespace('',NS)
def P(d,**attrs):return ['path',{'d':d,**attrs}]
def C(x,y,r,**attrs):return ['circle',{'cx':x,'cy':y,'r':r,**attrs}]
def R(x,y,w,h,rx=0,**attrs):return ['rect',{'x':x,'y':y,'width':w,'height':h,'rx':rx,**attrs}]
ICONS={}
def add(slug,label,category,nodes,aliases=''):
    ICONS[slug]={'label':label,'category':category,'aliases':aliases.split(','),'nodes':nodes}

add('meditation','Meditation','Experiences',[C(12,4.5,1.6),P('M8.5 10 Q12 7.5 15.5 10 M9 10 L8 14 L4 16 Q2.5 17.2 5 19 L10 19 M15 10 L16 14 L20 16 Q21.5 17.2 19 19 L14 19 M9 15 Q12 18 15 15 M10 19 Q12 16.5 14 19')],'mindfulness,stillness,sitting')
add('yoga','Yoga','Experiences',[C(12,4,1.5),P('M4 8 Q12 12 20 8 M12 9 V15 L7 20 M12 15 L17 20')],'asana,movement,stretch')
add('breathwork','Breathwork','Experiences',[P('M3 8 H14 Q19 8 19 4.5 Q19 2 16.5 3 M3 12 H18 Q22 12 21 9 M3 16 H12 Q17 16 17 19 Q17 22 14 21')],'breathing,air,calm')
add('nature-walk','Nature walk','Experiences',[P('M3 20 Q7 17 8 13 Q9 9 14 8 Q19 7 20 3 M4 10 Q3 5 8 4 Q10 8 4 10Z M14 17 Q17 12 21 14 Q21 19 14 17Z')],'trail,hiking,walking')
add('forest-bathing','Forest bathing','Experiences',[P('M4 13 L7 5 L10 13Z M7 13 V19 M12 12 L16 3 L20 12Z M16 12 V19 M3 21 Q12 18 21 21')],'forest,trees,woodland')
add('farm-experience','Farm experience','Experiences',[P('M3 20 H21 M5 20 V10 L12 4 L19 10 V20 M9 20 V14 H15 V20 M10 9 H14 M4 11 H20')],'farm,barn,agriculture')
add('gardening','Gardening','Experiences',[P('M12 18 V11 M12 13 Q5 13 5 6 Q12 6 12 13Z M12 10 Q12 3 19 3 Q19 10 12 10Z M5 20 Q12 16 19 20')],'garden,seed,planting,sprout')
add('birdwatching','Birdwatching','Experiences',[P('M3 13 Q8 14 10 9 Q12 4 16 7 L18 6 L18 9 L21 10 L18 11 Q17 17 11 17 Q6 17 3 13Z M10 12 Q13 12 15 10 M10 17 L9 20 M13 17 V20'),C(15.5,8.7,.55,fill='currentColor',stroke='none')],'bird,wildlife,nature')
add('stargazing','Stargazing','Experiences',[P('M12 3 L14.4 8 L20 8.8 L16 12.8 L17 18.5 L12 15.8 L7 18.5 L8 12.8 L4 8.8 L9.6 8Z M20 3 V5 M19 4 H21 M3 19 V21 M2 20 H4')],'stars,night,sky')
add('bonfire','Bonfire','Experiences',[P('M12 3 Q13 8 17 10 Q21 14 17 18 Q12 22 7 18 Q3 14 7 9 Q7 13 10 12 Q9 8 12 3Z M10 17 Q9 14 12 12 Q15 15 14 17 M5 21 L19 19 M5 19 L19 21')],'campfire,fire,evening')
add('workshop','Workshop','Experiences',[P('M3 5 Q8 3 12 5 Q16 3 21 5 V19 Q16 17 12 19 Q8 17 3 19Z M12 5 V19 M6 8 L9 8 M6 11 H9 M15 8 H18 M15 11 H18')],'learning,class,creative')
add('journaling','Journaling','Experiences',[R(4,3,14,18,2),P('M8 3 V21 M11 8 H15 M11 11 H15 M11 14 H14 M20 6 V17')],'journal,writing,reflection')

add('cottage','Cottage','Stay',[P('M3 11 L12 3 L21 11 M5 10 V21 H19 V10 M10 21 V15 H14 V21 M8 8 L12 5 L16 8')],'stay,home,cabin')
add('glamping','Glamping','Stay',[P('M3 20 L12 4 L21 20Z M7 20 L12 11 L17 20 M3 20 H21 M12 4 V2')],'tent,camping,stay')
add('restful-sleep','Restful sleep','Stay',[P('M3 19 V9 M21 19 V12 Q21 10 19 10 H10 V16 H21 M3 16 H21'),R(4,10,5,5,1.5),P('M13 4 Q16 6 19 3 Q20 7 16 8')],'bed,bedroom,sleep')
add('wifi','Wi-Fi','Stay',[P('M3 8 Q12 1 21 8 M6 12 Q12 7 18 12 M9 16 Q12 13 15 16'),C(12,20,.9,fill='currentColor',stroke='none')],'internet,wireless,connectivity')
add('shower','Shower','Stay',[P('M7 10 V7 Q7 3 11 3 Q15 3 15 7 M11 9 H19 Q19 6 15 6 Q11 6 11 9Z M12 13 L11 15 M16 13 L15 15 M20 13 L19 15 M11 18 L10 20 M15 18 L14 20 M19 18 L18 20')],'bath,bathroom,wash')
add('hot-water','Hot water','Stay',[P('M12 8 Q7 14 7 17 A5 5 0 0 0 17 17 Q17 14 12 8Z M8 3 Q6 5 8 7 M12 2 Q10 4 12 6 M16 3 Q14 5 16 7')],'warm,water,bath')
add('laundry','Laundry','Stay',[R(4,3,16,18,2),P('M4 8 H20'),C(12,14,4.5),P('M8 14 Q10 12 12 14 Q14 16 16 14'),C(7,5.5,.6,fill='currentColor',stroke='none')],'washing,clothes,amenity')
add('pet-friendly','Pet friendly','Stay',[P('M8 14 Q12 10 16 14 Q21 19 17 21 Q14 21 12 19 Q10 21 7 21 Q3 19 8 14Z'),C(5.5,9,1.5),C(10,5.5,1.5),C(15,5.5,1.5),C(19,9,1.5)],'pets,paw,dog')

add('farm-to-table','Farm to table','Dining',[P('M3 15 H21 Q20 21 12 21 Q4 21 3 15Z M12 14 V8 M12 10 Q6 10 6 4 Q12 4 12 10Z M12 8 Q12 2 18 3 Q18 8 12 8Z')],'food,produce,organic,seasonal')
add('vegetarian','Vegetarian','Dining',[P('M6 19 Q4 9 19 4 Q19 19 6 19Z M5 21 L16 8 M10 14 H14')],'plant-based,vegetable,leaf')
add('tea','Tea','Dining',[P('M4 10 H17 V15 Q17 19 11 19 Q4 19 4 15Z M17 11 H19 Q22 11 21 14 Q20 16 17 16 M3 21 H19 M8 3 Q6 5 8 7 M13 3 Q11 5 13 7')],'chai,herbal,drink')
add('drinking-water','Drinking water','Dining',[P('M6 9 H18 L16 21 H8Z M8 13 Q12 11 16 13 M12 2 Q9 5 10 6.5 Q12 9 14 6.5 Q15 5 12 2Z')],'water,refill,hydration')
add('breakfast','Breakfast','Dining',[P('M3 18 H21 M6 18 A6 6 0 0 1 18 18 M12 6 V3 M5 9 L3 7 M19 9 L21 7 M3 21 H21')],'morning,meal,sunrise')
add('community-dining','Community dining','Dining',[P('M5 12 H19 M7 12 V21 M17 12 V21 M3 15 V20 H5 M21 15 V20 H19 M8 8 Q12 6 16 8'),C(5,6,2),C(19,6,2)],'shared,table,meals')

add('calendar','Calendar','Planning',[R(3,5,18,16,2),P('M7 3 V7 M17 3 V7 M3 10 H21 M8 14 H10 M14 14 H16 M8 18 H10')],'date,availability,schedule')
add('location','Location','Planning',[P('M12 21 Q4 13 4 9 A8 7 0 0 1 20 9 Q20 13 12 21Z'),C(12,9,2.5)],'map,pin,address')
add('directions','Directions','Planning',[P('M12 2 L22 12 L12 22 L2 12Z M7 15 V11 H16 M13 8 L16 11 L13 14')],'route,navigation,travel')
add('time','Time','Planning',[C(12,12,9),P('M12 7 V12 L16 15')],'clock,duration,hours')
add('group-retreat','Group retreat','Planning',[C(12,6,2.5),C(5,9,2),C(19,9,2),P('M7 21 V18 Q7 13 12 13 Q17 13 17 18 V21 M2 20 V18 Q2 14 6 14 M22 20 V18 Q22 14 18 14')],'group,team,people')
add('private-retreat','Private retreat','Planning',[P('M3 11 L12 3 L21 11 M5 10 V21 H19 V10'),C(12,13,1.5),P('M9 19 Q9 16 12 16 Q15 16 15 19')],'personal,solo,privacy')
add('contact','Contact','Planning',[P('M4 4 H20 Q21 4 21 5 V15 Q21 16 20 16 H9 L4 21 V16 H4 Q3 16 3 15 V5 Q3 4 4 4Z M7 8 H17 M7 12 H14')],'message,chat,enquiry')
add('booking','Booking','Planning',[R(3,5,18,16,2),P('M7 3 V7 M17 3 V7 M3 10 H21 M8 16 L11 19 L17 13')],'reserve,reservation,confirmed')

add('wheelchair-access','Wheelchair access','Access & care',[C(13,4,1.5),P('M12 7 V13 H17 L20 19 M12 9 H17 M9 12 A5 5 0 1 0 15 19')],'accessible,accessibility,mobility')
add('step-free','Step-free route','Access & care',[P('M3 20 H21 M4 17 L18 8 V17 M5 7 H16 M13 4 L16 7 L13 10')],'ramp,access,level')
add('parking','Parking','Access & care',[R(3,3,18,18,3),P('M9 18 V7 H13 A3.5 3.5 0 0 1 13 14 H9')],'car,vehicle,arrival')
add('first-aid','First aid','Access & care',[R(3,7,18,14,2),P('M8 7 V4 H16 V7 M12 11 V17 M9 14 H15')],'medical,care,safety')
add('quiet-zone','Quiet zone','Access & care',[P('M4 9 H8 L13 5 V19 L8 15 H4Z M18 9 L22 13 M22 9 L18 13')],'silence,peace,quiet')
add('eco-care','Eco care','Access & care',[P('M3 17 L8 15 Q10 15 12 17 H17 Q20 17 21 19 L13 22 L3 20 M12 14 V8 M12 10 Q6 10 6 4 Q12 4 12 10Z M12 8 Q12 2 18 3 Q18 8 12 8Z')],'sustainability,stewardship,environment')

add('search','Search','Interface',[C(10.5,10.5,6.5),P('M15.5 15.5 L21 21')],'find,lookup')
add('menu','Menu','Interface',[P('M4 6 H20 M4 12 H20 M4 18 H20')],'navigation,hamburger')
add('close','Close','Interface',[P('M6 6 L18 18 M18 6 L6 18')],'dismiss,cancel')
add('arrow-right','Arrow right','Interface',[P('M3 12 H21 M14 5 L21 12 L14 19')],'next,forward,continue')
add('chevron-down','Chevron down','Interface',[P('M5 9 L12 16 L19 9')],'expand,dropdown,more')
add('check','Check','Interface',[P('M4 12 L9 17 L20 6')],'done,success,tick')
add('download','Download','Interface',[P('M12 3 V16 M7 11 L12 16 L17 11 M4 17 V21 H20 V17')],'save,file')
add('external-link','External link','Interface',[P('M14 3 H21 V10 M21 3 L10 14 M10 4 H4 V20 H20 V14')],'open,new-tab')
assert len(ICONS)==48

def save(path,data):
    p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data if isinstance(data,bytes) else data.encode());return p
def svg(slug,weight='regular',colour='currentColor',label=True):
    root=ET.Element('svg',{'xmlns':NS,'viewBox':'0 0 24 24','width':'24','height':'24','fill':'none','stroke':colour,'stroke-width':'1.75' if weight=='regular' else '2.25','stroke-linecap':'round','stroke-linejoin':'round'})
    if label:
        root.set('role','img');root.set('aria-label',ICONS[slug]['label'])
        ET.SubElement(root,'title').text=ICONS[slug]['label']
    else:root.set('aria-hidden','true');root.set('focusable','false')
    for tag,attrs in ICONS[slug]['nodes']:
        attrs={k:str(v) for k,v in attrs.items()}
        if colour!='currentColor':attrs={k:v.replace('currentColor',colour) for k,v in attrs.items()}
        ET.SubElement(root,tag,attrs)
    return root
def xml(r):return ET.tostring(r,encoding='utf-8',xml_declaration=True)
catalog=[]
for slug,info in ICONS.items():
    for weight in ['regular','strong']:
        for mode,colour in [('current', 'currentColor'),('forest',G),('white',W)]:save(Path('svg')/weight/mode/f'{slug}.svg',xml(svg(slug,weight,colour)))
    for mode,colour in [('forest',G),('white',W)]:
        for size in [24,48,96]:save(Path('png')/mode/f'{slug}-{size}.png',cairosvg.svg2png(bytestring=xml(svg(slug,'regular',colour)),output_width=size,output_height=size))
    catalog.append({'name':slug,'label':info['label'],'category':info['category'],'aliases':info['aliases'],'viewBox':'0 0 24 24','regularStroke':1.75,'strongStroke':2.25,'minimumPx':20 if info['category']=='Interface' else 24})
for weight in ['regular','strong']:
    sprite=ET.Element('svg',{'xmlns':NS})
    for slug in ICONS:
        symbol=ET.SubElement(sprite,'symbol',{'id':'aroha-'+slug,'viewBox':'0 0 24 24','fill':'none','stroke':'currentColor','stroke-width':'1.75' if weight=='regular' else '2.25','stroke-linecap':'round','stroke-linejoin':'round'})
        for tag,attrs in ICONS[slug]['nodes']:ET.SubElement(symbol,tag,{k:str(v) for k,v in attrs.items()})
    save(Path('web')/f'aroha-icons-{weight}.svg',xml(sprite))
save(Path('catalog.json'),json.dumps({'version':'1.1.0','brandSystem':'Aroha v2','icons':catalog},indent=2))
save(Path('source/icon-definitions.json'),json.dumps(ICONS,indent=2))
save(Path('source/build_service_icons.py'),Path(__file__).read_bytes())
save(Path('source/requirements.txt'),'cairosvg\npillow\nreportlab\nsvglib\npymupdf\n')
save(Path('source/BUILD.md'),'Run build_service_icons.py --brand PATH_TO_AROHA_V2 --output NEW_FOLDER. The brand folder supplies the licensed Lora and Source Sans 3 fonts. CairoSVG requires system Cairo. Do not rebuild over a modified release.\n')

# A small optional React adapter; ordinary SVG and sprites need no framework.
react='''"use client";
import { createElement, useId, type SVGProps } from "react";
export const iconDefinitions = '''+json.dumps(ICONS,ensure_ascii=False)+''' as const;
export type ArohaIconName = keyof typeof iconDefinitions;
type Props = Omit<SVGProps<SVGSVGElement>, "children" | "viewBox" | "role" | "aria-hidden" | "aria-labelledby" | "name"> & {name:ArohaIconName;size?:number;weight?:"regular"|"strong";title?:string};
export function ArohaIcon({name,size=24,weight="regular",title,...props}:Props){
 const titleId=useId();
 return <svg {...props} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={weight==="strong"?2.25:1.75} strokeLinecap="round" strokeLinejoin="round" focusable="false" role={title?"img":undefined} aria-hidden={title?undefined:true} aria-labelledby={title?titleId:undefined}>
  {title&&<title id={titleId}>{title}</title>}
  {iconDefinitions[name].nodes.map(([tag,attrs],i)=>createElement(tag,{...attrs,key:i}))}
 </svg>;
}
'''
save(Path('react/ArohaIcon.tsx'),react)
save(Path('react/README.md'),'''# Optional React component
Requires React 18+ and TypeScript/JSX in the consuming app. No icon-font dependency.
Copy ArohaIcon.tsx, then import { ArohaIcon } from './ArohaIcon'.
Decorative next to visible text: <ArohaIcon name="gardening" />
Meaningful standalone image: <ArohaIcon name="gardening" title="Gardening" />
Icon-only control: <button aria-label="Search"><ArohaIcon name="search" /></button>
Colour inherits from the parent. Use weight="strong" at compact sizes if needed.
The helper is a client component because it uses useId for unique accessible title IDs.
''')
save(Path('web/icons.css'),'.aroha-icon{width:24px;height:24px;display:inline-block;flex:none;vertical-align:middle;fill:none;stroke:currentColor;stroke-width:1.75;stroke-linecap:round;stroke-linejoin:round}.aroha-icon--strong{stroke-width:2.25}.aroha-icon--feature{width:48px;height:48px}.aroha-icon-button{min-width:48px;min-height:48px;display:inline-flex;align-items:center;justify-content:center}\n')

# Fonts are the same selected families as the brand standard.
for family in ['Lora','SourceSans3']:
    src=a.brand/'04-typography/fonts'/family
    for file in [f'{family}-Variable.woff2','OFL.txt']:
        save(Path('docs/fonts')/family/file,(src/file).read_bytes())
for family,weight in [('Lora',500),('SourceSans3',400),('SourceSans3',600)]:
    pdfmetrics.registerFont(TTFont(f'{family}-{weight}',str(a.brand/'04-typography/fonts'/family/f'{family}-{weight}.ttf')))

cards=''.join(f'<button type="button" class="icon-card" data-name="{slug}" data-category="{info["category"]}" aria-pressed="{str(i==0).lower()}">{ET.tostring(svg(slug,label=False),encoding="unicode")}<span>{info["label"]}</span><small>{slug}</small></button>' for i,(slug,info) in enumerate(ICONS.items()))
categories=list(dict.fromkeys(info['category'] for info in ICONS.values()))
html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aroha / Service & feature icons</title><style>
@font-face{font-family:Lora;src:url(fonts/Lora/Lora-Variable.woff2);font-weight:400 700;font-display:swap}@font-face{font-family:Source;src:url(fonts/SourceSans3/SourceSans3-Variable.woff2);font-weight:200 900;font-display:swap}*{box-sizing:border-box}body{margin:0;background:#fff;color:#163E2D;font:18px/1.55 Source,sans-serif}main{max-width:1320px;margin:auto;padding:48px 28px 80px}h1,h2,h3{font-family:Lora,serif;font-weight:500;line-height:1.15}h1{font-size:clamp(40px,5vw,64px);max-width:960px}h2{font-size:32px}.eyebrow{font-size:13px;letter-spacing:.1em;font-weight:600}.intro{font-size:22px;max-width:860px}.toolbar{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:16px;margin-top:32px}label{display:block;font-size:15px;font-weight:600}input,select,button,textarea{font:inherit}input,select{display:block;width:100%;min-height:48px;padding:10px 12px;border:1px solid #9EADA4;border-radius:8px;background:#fff;color:#163E2D}button{cursor:pointer}button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid #163E2D;outline-offset:4px}.layout{display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:28px;align-items:start}.gallery{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.icon-card{border:1px solid #DDE5D7;border-radius:10px;padding:22px 12px;background:white;color:var(--icon-color,#163E2D);display:flex;flex-direction:column;align-items:center;gap:14px;min-height:160px}.icon-card[hidden]{display:none}.icon-card[aria-pressed="true"]{outline:2px solid #163E2D;outline-offset:-2px}.icon-card svg{width:var(--icon-size,32px);height:var(--icon-size,32px);flex:none}.icon-card span{color:#163E2D;font-size:16px;font-weight:600;text-align:center}.icon-card small{font-size:12px;color:#52665A;overflow-wrap:anywhere}.icon-card[data-white="true"]{background:#163E2D}.icon-card[data-white="true"] span,.icon-card[data-white="true"] small{color:#fff}.inspector{position:sticky;top:24px;border:1px solid #DDE5D7;border-radius:12px;padding:24px;overflow:hidden}.inspector h2{font-size:26px;margin-top:0}.inspector .sample{display:flex;align-items:center;justify-content:center;min-height:140px;color:var(--icon-color,#163E2D);background:var(--sample-surface,#fff);border:1px solid #DDE5D7;border-radius:8px}.sample svg{width:80px;height:80px}.inspector p{font-size:16px}textarea{width:100%;height:210px;resize:vertical;padding:12px;font-size:12px;line-height:1.5;border:1px solid #DDE5D7;border-radius:8px;color:#163E2D;background:#fff}.action{min-height:48px;padding:10px 16px;border:1px solid #163E2D;border-radius:8px;background:#163E2D;color:#fff;font-weight:600}a{color:inherit;text-underline-offset:4px}.message{min-height:28px;font-size:15px}.guide{margin-top:48px;border-top:1px solid #DDE5D7;padding-top:28px}.examples{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:24px}.feature{border:1px solid #DDE5D7;border-radius:12px;padding:24px}.feature svg{width:40px;height:40px}.feature h3{font-size:24px}.feature p{font-size:16px}.code{background:#F7F9F6;padding:20px;white-space:pre-wrap;font-size:14px;overflow-wrap:anywhere}.empty{padding:24px;border:1px solid #DDE5D7}table{width:100%;border-collapse:collapse;font-size:16px}th,td{text-align:left;padding:12px;border-bottom:1px solid #DDE5D7}section{scroll-margin-top:24px}@media(hover:hover) and (pointer:fine){.icon-card:hover{border-color:#163E2D}}@media(max-width:1050px){.gallery{grid-template-columns:repeat(3,minmax(0,1fr))}.layout{grid-template-columns:minmax(0,1fr) 270px}}@media(max-width:760px){main{padding:28px 20px 64px}.toolbar{grid-template-columns:1fr 1fr}.toolbar label:first-child{grid-column:1/-1}.layout{grid-template-columns:1fr}.gallery{grid-template-columns:repeat(3,minmax(0,1fr))}.inspector{position:static}.examples{grid-template-columns:1fr}.intro{font-size:20px}}@media(max-width:420px){.gallery{grid-template-columns:repeat(2,minmax(0,1fr))}.toolbar{grid-template-columns:1fr}.toolbar label:first-child{grid-column:auto}}
</style><main><header><div class="eyebrow">AROHA RETREAT / SERVICE & FEATURE ICONS / V1.1</div><h1>A nature-inspired language for the retreat.</h1><p class="intro">48 original icons for experiences, facilities, planning and care. Rounded strokes and organic curves keep the family connected to Aroha while each symbol carries a clear meaning.</p><p>All icon files have transparent backgrounds. The gallery uses white by default; choosing a white icon adds a dark preview surface only.</p><p><a href="Aroha-Service-Icon-Standards.pdf">Design standards PDF</a> · <a href="../catalog.json">Icon catalogue</a> · <a href="Integration.md">Integration guide</a></p></header><div class="toolbar"><label>Search icons<input id="search" type="search" placeholder="Try yoga, water or booking" autocomplete="off"></label><label>Category<select id="category"><option value="all">All categories</option>'''+''.join(f'<option>{cat}</option>' for cat in categories)+'''</select></label><label>Stroke<select id="weight"><option value="regular">Regular / 1.75</option><option value="strong">Strong / 2.25</option></select></label><label>Preview size<select id="size"><option>20</option><option>24</option><option selected>32</option><option>48</option></select></label></div><label style="max-width:240px;margin-top:16px">Icon colour<select id="colour"><option value="#163E2D">Forest</option><option value="#FFFFFF">White</option><option value="#000000">Black / currentColor</option></select></label><p class="message" id="count" role="status">48 icons</p><div class="layout"><section aria-label="Icon gallery"><div class="gallery">'''+cards+'''</div><p class="empty" id="empty" hidden>No matching icons. Try another service name or category.</p></section><aside class="inspector" aria-label="Selected icon"><h2 id="selected-label">Meditation</h2><div class="sample" id="sample"></div><p id="selected-name">meditation</p><button class="action" id="copy">Copy SVG</button><p class="message" id="copy-status" role="status"></p><label for="source">Selected SVG source</label><textarea id="source" readonly spellcheck="false"></textarea><p><a id="download" download="meditation.svg">Download SVG</a></p></aside></div><section class="guide"><h2>One family. Clear roles.</h2><table><tr><th>Use</th><th>Recommended size / stroke</th></tr><tr><td>Interface controls</td><td>20–24 px; regular or strong</td></tr><tr><td>Service cards and feature lists</td><td>24–48 px; regular</td></tr><tr><td>Large editorial highlights</td><td>48–96 px; keep stroke proportional</td></tr><tr><td>Favicon or retreat logo</td><td>Use the existing brand icon family, separately supplied</td></tr></table><p>24 × 24 master grid; regular stroke 1.75 units; strong stroke 2.25 units; round caps and joins. Keep a minimum 0.75-unit outer safety margin including the stroke. Use the same weight across a local component group.</p><p>The artwork is language-neutral. Localise the visible service label. Use access and amenity symbols only for verified features of the retreat; this catalogue does not assert service availability.</p><h2>Example service cards</h2><p>These are visual examples, not published service listings.</p><div class="examples">'''+''.join('<article class="feature">'+ET.tostring(svg(slug,label=False),encoding='unicode')+f'<h3>{ICONS[slug]["label"]}</h3><p>{body}</p></article>' for slug,body in [('meditation','Give the experience a short, specific label and describe what a guest can expect.'),('farm-to-table','Use an image or description to explain the actual food offering alongside the icon.'),('nature-walk','Keep practical details such as duration and meeting point in accessible text.')])+'''</div><h2>Accessible implementation</h2><p>Next to visible text, hide the icon from assistive technology. In an icon-only button, name the button itself and keep its target at least 48 × 48 px. Icon shape and colour alone should not carry availability or error status.</p><pre class="code">&lt;svg class="aroha-icon" aria-hidden="true"&gt;
  &lt;use href="/brand/aroha-icons-regular.svg#aroha-gardening"&gt;&lt;/use&gt;
&lt;/svg&gt;
&lt;span&gt;Gardening&lt;/span&gt;

&lt;button aria-label="Search"&gt;
  &lt;ArohaIcon name="search" /&gt;
&lt;/button&gt;</pre><p>Use the SVG sprite from the same origin or inline it once. Inline/currentColor SVG and the React helper inherit CSS colour; SVGs embedded as images do not inherit their host element’s colour. PNGs are fixed-colour transparent exports.</p><p>Motion is optional and follows the Aroha nature-motion rules: keep reading content still, use short feedback, respect reduced motion and avoid automatic icon loops.</p><p>Sources: <a href="https://developers.google.com/fonts/docs/material_symbols">Google Material Symbols design variables</a> and <a href="https://react.dev/reference/react/useId">React accessible IDs</a>. These are design and implementation references; the icon paths in this pack are custom artwork.</p></section></main><script>
const ICONS='''+json.dumps(ICONS)+''';
const cards=[...document.querySelectorAll('.icon-card')];let selected='meditation';let objectUrl;
const $=id=>document.getElementById(id);
function svgText(name){const info=ICONS[name];const width=$('weight').value==='regular'?1.75:2.25;const c=$('colour').value;return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="'+c+'" stroke-width="'+width+'" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="'+info.label+'"><title>'+info.label+'</title>'+info.nodes.map(([tag,attrs])=>'<'+tag+' '+Object.entries(attrs).map(([k,v])=>k+'="'+String(v).replaceAll('currentColor',c)+'"').join(' ')+'/>').join('')+'</svg>';}
function inspect(){const info=ICONS[selected];const source=svgText(selected);$('selected-label').textContent=info.label;$('selected-name').textContent=selected+' / '+info.category;$('sample').innerHTML=source;$('source').value=source;$('copy-status').textContent='';if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl=URL.createObjectURL(new Blob([source],{type:'image/svg+xml'}));$('download').href=objectUrl;$('download').download=selected+'.svg';cards.forEach(c=>c.setAttribute('aria-pressed',String(c.dataset.name===selected)));}
function filter(){const q=$('search').value.trim().toLowerCase(),cat=$('category').value;let n=0;cards.forEach(c=>{const i=ICONS[c.dataset.name];const show=(cat==='all'||cat===i.category)&&[c.dataset.name,i.label,...i.aliases].join(' ').toLowerCase().includes(q);c.hidden=!show;if(show)n++;});$('count').textContent=n+' of 48 icons';$('empty').hidden=n!==0;}
function restyle(){const color=$('colour').value;document.documentElement.style.setProperty('--icon-size',$('size').value+'px');document.documentElement.style.setProperty('--icon-color',color);document.documentElement.style.setProperty('--sample-surface',color==='#FFFFFF'?'#163E2D':'#FFFFFF');cards.forEach(c=>{c.dataset.white=String(color==='#FFFFFF');c.querySelector('svg').setAttribute('stroke-width',$('weight').value==='regular'?'1.75':'2.25');});inspect();}
cards.forEach(c=>c.addEventListener('click',()=>{selected=c.dataset.name;inspect();}));['search','category'].forEach(id=>$(id).addEventListener(id==='search'?'input':'change',filter));['weight','size','colour'].forEach(id=>$(id).addEventListener('change',restyle));$('copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('source').value);$('copy-status').textContent='SVG copied.';}catch{$('source').focus();$('source').select();$('copy-status').textContent='Select and copy the SVG source below.';}});restyle();filter();
</script></html>'''
save(Path('docs/Icon-Catalogue.html'),html)
save(Path('docs/Integration.md'),'''# Aroha service icon integration

Use svg/regular/current for inline recolourable source. Use fixed forest/white SVG with image tags.
Use svg/strong when compact controls need a stronger stroke. PNG exports are regular at 24, 48 and 96px.
Web sprite IDs are stable: aroha-<name>, for example aroha-meditation.
Host sprites on the same origin. Inline the sprite if a particular browser cannot load external use references.
Set width/height and CSS colour on the SVG. Avoid filter recolouring of fixed PNGs.
React adapter: react/ArohaIcon.tsx. Requires React 18+ with TypeScript/JSX. useId prevents duplicate title IDs.

## Accessibility
Decorative next to visible text: aria-hidden=true and focusable=false.
Standalone meaningful icon: role=img with a meaningful label or unique title ID.
Icon-only button: accessible name goes on the button; the child icon is decorative.
48px targets are independent of a 20/24px drawing. Keep a visible keyboard focus ring.
Verify 3:1 contrast for meaningful graphical controls. Forest/white are the default strong-contrast pair.
Provide text for service availability, status, duration, fees and accessible-route details.
Do not treat an accessibility icon as evidence that a facility meets access requirements.

## Scope
40 service/feature assets and 8 familiar interface controls. Language-neutral art; localise labels separately.
The supplied catalogue is a design asset list, not a statement of offered services or amenities.
All standalone icon backgrounds are transparent. Dark gallery surfaces only preview white artwork.
Use the brand mark and micro favicon from Aroha Brand System v2 for brand identification.

## Design rules
24-unit square; regular 1.75 and strong 2.25 strokes; rounded caps and joins.
Use regular at 24-48px for features; strong can help compact 20px controls.
Do not change the weight of individual shapes, add leaf decorations to controls, or mix weights in one row.
No letterforms, gradients, shadows or embedded backgrounds. Icons remain static by default.
Optional motion follows the existing nature-motion standard; avoid decorative movement of reading content.

## Sources and provenance
Paths are custom SVG geometry made for Aroha, not copied Material Symbols.
Reference: https://developers.google.com/fonts/docs/material_symbols
React IDs: https://react.dev/reference/react/useId
Lora and Source Sans 3 are the existing brand families. Their OFL files accompany the preview fonts.
''')

# Standards PDF and a one-page labelled contact sheet.
def draw_icon(c,slug,x,y,size=40,weight='regular'):
    d=svg2rlg(io.BytesIO(xml(svg(slug,weight,G))));d.scale(size/24,size/24);renderPDF.draw(d,c,x,y)
pdf=OUT/'docs/Aroha-Service-Icon-Standards.pdf';c=canvas.Canvas(str(pdf),pagesize=(842,595));c.setTitle('Aroha / service and feature icon standards')
def page(n,title,sub):
    c.setFillColor(HexColor(W));c.rect(0,0,842,595,fill=1,stroke=0);c.setFillColor(HexColor(G));c.setFont('SourceSans3-600',10);c.drawString(44,555,'AROHA RETREAT / SERVICE & FEATURE ICONS / V1.1')
    c.setFont('Lora-500',29);c.drawString(44,500,title);c.setFont('SourceSans3-400',12);c.drawString(44,475,sub);c.setStrokeColor(HexColor('#DDE5D7'));c.line(44,40,798,40);c.setFont('SourceSans3-400',9);c.drawString(44,24,'24-UNIT GRID / TRANSPARENT ARTWORK / 31 OCTOBER 2026');c.drawRightString(798,24,str(n))
def lines(x,y,items,size=12,lead=20):
    c.setFillColor(HexColor(G));c.setFont('SourceSans3-400',size)
    for line in items:c.drawString(x,y,line);y-=lead
def gallery(slugs,cols=4):
    for i,slug in enumerate(slugs):
        centre=44+(i%cols+.5)*(754/cols);y=365-(i//cols)*90
        draw_icon(c,slug,centre-20,y,40)
        c.setFillColor(HexColor(G));c.setFont('SourceSans3-400',10)
        c.drawCentredString(centre,y-20,ICONS[slug]['label'])
        c.setFont('SourceSans3-400',9);c.drawCentredString(centre,y-35,slug)
page(1,'A family for the retreat','Original icons for experiences, facilities, planning and clear website interaction.')
for i,slug in enumerate(['meditation','nature-walk','farm-to-table','cottage','gardening','booking']):draw_icon(c,slug,44+(i+.5)*754/6-32,350,64)
lines(44,300,['48 icons: 40 service/feature assets and 8 common interface controls.','24 x 24 master grid. Regular stroke 1.75 units; strong stroke 2.25 units.','Rounded caps and joins; at least 0.75 units of outer safety margin including the stroke.','', 'Features: 24-48 px regular. Compact controls: 20-24 px; use strong if needed.','Keep the same weight across a local component group. Retain recognisable control shapes.','Backgrounds are transparent. Forest and white exports match the Aroha v2 palette.','', 'The catalogue describes assets; it does not confirm that services or facilities are offered.']);c.showPage()
for num,title,cats in [(2,'Experiences',['Experiences']),(3,'Stay & dining',['Stay','Dining']),(4,'Planning, access & care',['Planning','Access & care'])]:
    page(num,title,'Use a clear visible label and add practical details in accessible text.');gallery([s for s,i in ICONS.items() if i['category'] in cats]);c.showPage()
page(5,'Controls & optical consistency','Familiar control shapes keep navigation predictable.');gallery([s for s,i in ICONS.items() if i['category']=='Interface'])
lines(44,190,['Use the regular weight for standard 24px controls. Strong adds emphasis at compact sizes.','A 24px icon still needs a 48px pointer target and a visible keyboard focus indicator.','Next to visible text, mark the icon decorative. In an icon-only button, name the button.','Service availability and validation states require text; shape or colour alone is insufficient.','Keep the detailed brand logo and favicon in the separate Aroha brand icon family.']);c.showPage()
page(6,'Production & implementation','SVG source, sprites, transparent PNGs and an optional typed React adapter.')
lines(44,425,['SVG: regular and strong weights in currentColor, forest and white.','PNG: regular forest/white at 24, 48 and 96px, with true alpha transparency.','Sprites: web/aroha-icons-regular.svg and aroha-icons-strong.svg; IDs start with aroha-.','React: ArohaIcon.tsx with typed icon names, size, weight and optional accessible title.','', 'Inline SVG and sprites can inherit CSS colour. Image-tag SVGs use their own document colour.','Use a same-origin sprite URL, or inline the sprite once if external use is unsuitable.','The catalogue preview has search, categories, colour/size/weight controls and source download.','', 'Art is language-neutral; localise visible labels. Access and amenity claims need verified details.','The icon paths are custom artwork. Material design variables were a reference, not source artwork.','Preview fonts reuse Lora and Source Sans 3, with their original OFL licences included.','', 'References: developers.google.com/fonts/docs/material_symbols and react.dev/reference/react/useId'],12,21);c.showPage();c.save()
sheet=OUT/'docs/Aroha-48-Icon-Contact-Sheet.pdf';c=canvas.Canvas(str(sheet),pagesize=(842,595));c.setTitle('Aroha / 48-icon contact sheet');page(1,'Aroha / 48-icon overview','Regular stroke / forest on white / labels are included for reference.')
for i,(slug,info) in enumerate(ICONS.items()):
    centre=44+(i%8+.5)*754/8;y=400-(i//8)*62
    draw_icon(c,slug,centre-15,y,30)
    c.setFillColor(HexColor(G));c.setFont('SourceSans3-400',8);c.drawCentredString(centre,y-14,info['label'])
c.showPage();c.save()

save(Path('README.txt'),'''AROHA / SERVICE & FEATURE ICON PACK V1.1
Open docs/Icon-Catalogue.html for searchable icons, source selection and live weight/size/colour previews.
Read docs/Aroha-Service-Icon-Standards.pdf. docs/Aroha-48-Icon-Contact-Sheet.pdf is the full contact sheet.
48 icons in six categories. Original 24-unit vector geometry, rounded caps and joins.
svg/regular and svg/strong: currentColor, forest, white. Strong uses 2.25 stroke; regular 1.75.
png/: regular forest and white at 24/48/96px. Transparent backgrounds in every icon.
web/: two SVG sprites and CSS. react/: optional typed React 18+ adapter.
catalog.json: stable names and semantic metadata. source/: definitions and reproducible builder.
Brand mark and favicon are in the separate Aroha Brand System v2 package.
An asset in this catalogue is not a statement that the retreat offers that facility or service.
Preview fonts are bundled with OFL licences. Icon paths are custom geometry, not third-party icon paths.
''')

# Meaningful checks: all definitions render, both weights have unclipped alpha, sprites stay unique.
checks={'icons':48,'categories':len(categories),'pngsTransparent':0,'svgWeightBoundsChecked':0,'duplicates':False}
signatures=set()
for slug,info in ICONS.items():
    sig=json.dumps(info['nodes'],sort_keys=True);assert sig not in signatures;signatures.add(sig)
    for weight in ['regular','strong']:
        im=Image.open(io.BytesIO(cairosvg.svg2png(bytestring=xml(svg(slug,weight,G)),output_width=240)))
        bbox=im.getchannel('A').getbbox();assert bbox and bbox[0]>=8 and bbox[1]>=8 and bbox[2]<=232 and bbox[3]<=232,(slug,weight,bbox)
        checks['svgWeightBoundsChecked']+=1
for file in (OUT/'png').rglob('*.png'):
    im=Image.open(file);assert im.mode=='RGBA' and im.getchannel('A').getextrema()[0]==0;checks['pngsTransparent']+=1
save(Path('docs/Audit-Report.json'),json.dumps(checks,indent=2))
inventory=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='manifest.json']
save(Path('manifest.json'),json.dumps({'version':'1.1.0','files':inventory},indent=2))
with zipfile.ZipFile(OUT.parent/'Aroha-Service-Feature-Icons-v1.1.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file():z.write(p,Path(OUT.name)/p.relative_to(OUT))
print(json.dumps({'icons':48,'files':len(inventory)+1,'checks':checks,'package':str(OUT.parent/'Aroha-Service-Feature-Icons-v1.1.zip')},indent=2))
