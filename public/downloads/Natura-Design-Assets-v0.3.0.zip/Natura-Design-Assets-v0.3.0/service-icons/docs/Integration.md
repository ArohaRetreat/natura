# Aroha service icon integration

Use svg/regular/current for inline recolourable source. Use fixed forest/white SVG with image tags.
Use svg/strong when compact controls need a stronger stroke. PNG exports are regular at 24, 48 and 96px.
Web sprite IDs are stable: aroha-<name>, for example aroha-meditation.
Host sprites on the same origin. Inline the sprite if a particular browser cannot load external use references.
Set width/height and CSS colour on the SVG. Avoid filter recolouring of fixed PNGs.
React adapter: react/ArohaIcon.tsx. Requires React 18+ with TypeScript/JSX. useId prevents duplicate title IDs.

## Accessibility
Decorative next to visible text: aria-hidden=true and focusable=false.
Standalone meaningful icon: role=img with a meaningful label or unique title ID.
Icon-only button: accessible name goes on the button; the child icon is decorative.
48px targets are independent of a 20/24px drawing. Keep a visible keyboard focus ring.
Verify 3:1 contrast for meaningful graphical controls. Forest/white are the default strong-contrast pair.
Provide text for service availability, status, duration, fees and accessible-route details.
Do not treat an accessibility icon as evidence that a facility meets access requirements.

## Scope
40 service/feature assets and 8 familiar interface controls. Language-neutral art; localise labels separately.
The supplied catalogue is a design asset list, not a statement of offered services or amenities.
All standalone icon backgrounds are transparent. Dark gallery surfaces only preview white artwork.
Use the brand mark and micro favicon from Aroha Brand System v2 for brand identification.

## Design rules
24-unit square; regular 1.75 and strong 2.25 strokes; rounded caps and joins.
Use regular at 24-48px for features; strong can help compact 20px controls.
Do not change the weight of individual shapes, add leaf decorations to controls, or mix weights in one row.
No letterforms, gradients, shadows or embedded backgrounds. Icons remain static by default.
Optional motion follows the existing nature-motion standard; avoid decorative movement of reading content.

## Sources and provenance
Paths are custom SVG geometry made for Aroha, not copied Material Symbols.
Reference: https://developers.google.com/fonts/docs/material_symbols
React IDs: https://react.dev/reference/react/useId
Lora and Source Sans 3 are the existing brand families. Their OFL files accompany the preview fonts.
