AROHA / SERVICE & FEATURE ICON PACK V1.1
Open docs/Icon-Catalogue.html for searchable icons, source selection and live weight/size/colour previews.
Read docs/Aroha-Service-Icon-Standards.pdf. docs/Aroha-48-Icon-Contact-Sheet.pdf is the full contact sheet.
48 icons in six categories. Original 24-unit vector geometry, rounded caps and joins.
svg/regular and svg/strong: currentColor, forest, white. Strong uses 2.25 stroke; regular 1.75.
png/: regular forest and white at 24/48/96px. Transparent backgrounds in every icon.
web/: two SVG sprites and CSS. react/: optional typed React 18+ adapter.
catalog.json: stable names and semantic metadata. source/: definitions and reproducible builder.
Brand mark and favicon are in the separate Aroha Brand System v2 package.
An asset in this catalogue is not a statement that the retreat offers that facility or service.
Preview fonts are bundled with OFL licences. Icon paths are custom geometry, not third-party icon paths.
