/* Explicit preview playback. No external dependencies, autoplay or rAF loop. */
const ease='cubic-bezier(.23,1,.32,1)';
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
const owned=new Set();
const enabled=document.querySelector('#motion-enabled');
const status=document.querySelector('#motion-status');
function stopAll(){for(const a of owned)a.cancel();owned.clear();}
function animate(target,frames,options){const a=target.animate(frames,{easing:ease,...options});owned.add(a);a.finished.catch(()=>{}).finally(()=>owned.delete(a));return a;}
function announce(message){status.textContent=message;}
document.querySelectorAll('[data-play]').forEach(button=>button.addEventListener('click',event=>{
  stopAll();
  const card=button.closest('[data-effect]');const effect=card.dataset.effect;
  const art=card.querySelector('.motion-art');
  if(!enabled.checked||event.detail===0){announce(button.textContent.trim()+': final state shown without movement.');return;}
  if(reduced.matches||document.querySelector('#reduced-preview').checked){animate(art,[{opacity:.45},{opacity:1}],{duration:150});announce('Reduced motion: a gentle fade replaces movement.');return;}
  let last;
  if(effect==='leaf')last=animate(art,[{transform:'translateY(-8px) rotate(-2deg)',opacity:0},{transform:'translateY(0px) rotate(0deg)',opacity:1}],{duration:240});
  if(effect==='seed'){art.style.transformOrigin='50% 100%';last=animate(art,[{transform:'translateY(6px) scale(.96)',opacity:0},{transform:'translateY(0px) scale(1)',opacity:1}],{duration:240});}
  if(effect==='water'){
    for(const [i,ring] of [...card.querySelectorAll('.water-ring')].entries())last=animate(ring,[{transform:'scale(.95)',opacity:.55},{transform:'scale(1.6)',opacity:0}],{duration:220,delay:i*30});
  }
  if(effect==='path')for(const [i,segment] of [...card.querySelectorAll('.path-segment')].entries())last=animate(segment,[{transform:'translateX(-6px)',opacity:0},{transform:'translateX(0px)',opacity:1}],{duration:200,delay:i*30});
  announce(button.textContent.trim()+': playing once.');
  if(last)last.finished.then(()=>announce(button.textContent.trim()+': complete.')).catch(()=>{});
}));
document.querySelector('#stop-motion').addEventListener('click',()=>{stopAll();announce('Preview stopped. All artwork is at rest.');});
enabled.addEventListener('change',()=>{stopAll();announce(enabled.checked?'Preview enabled. Press a Play button to begin.':'Motion disabled. Artwork stays at rest.');});
document.querySelector('#reduced-preview').addEventListener('change',()=>{stopAll();announce('Reduced-motion preview setting updated.');});
reduced.addEventListener('change',()=>{stopAll();announce(reduced.matches?'System reduced-motion setting detected.':'System movement preference restored.');});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAll();});
document.querySelectorAll('button[data-surface]').forEach(button=>button.addEventListener('click',()=>{
 document.body.dataset.surface=button.dataset.surface;
 document.querySelectorAll('button[data-surface]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
}));
