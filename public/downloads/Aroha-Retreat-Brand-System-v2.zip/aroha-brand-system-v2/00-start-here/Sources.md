# Sources checked 31 October 2026

[Material Design / product icon principles](https://m1.material.io/style/icons.html)

Historical Material reference: simple silhouettes, keylines, optical consistency; no legacy shadows adopted.

[Material Design 3 / icon overview](https://m3.material.io/styles/icons/overview)

Current landing page; JavaScript-only in text fetch. Detailed dimensions taken from Android documentation.

[Android adaptive icon specification](https://developer.android.com/develop/ui/compose/system/icon_design_adaptive)

108dp layers, safe content placement, separate foreground/background and monochrome.

[Google Play icon specification](https://developer.android.com/distribute/google-play/resources/icon-design-specifications)

512px square sRGB PNG; platform mask and shadows. Store upload needs a separate opaque composite.

[Google Search favicon guidance](https://developers.google.com/search/docs/appearance/favicon-in-search)

Square, stable URL, crawlable; 96px PNG supplied for search.

[Lora / official description](https://raw.githubusercontent.com/google/fonts/main/ofl/lora/DESCRIPTION.en_us.html)

Calligraphic curves, moderate contrast, screen and print use.

[Source Sans 3 / official description](https://raw.githubusercontent.com/google/fonts/main/ofl/sourcesans3/DESCRIPTION.en_us.html)

Interface-oriented sans serif.

[Noto Serif Kannada / official metadata](https://raw.githubusercontent.com/google/fonts/main/ofl/notoserifkannada/METADATA.pb)

Kannada serif family and OFL license.

[Noto Sans Kannada / official metadata](https://raw.githubusercontent.com/google/fonts/main/ofl/notosanskannada/METADATA.pb)

Kannada sans family and OFL license.

[WCAG 2.2 / text contrast](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html)

Normal text 4.5:1; large text 3:1. Logos are exempt, but interface text is not.

[WCAG 2.2 / non-text contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html)

Meaningful control boundaries and graphics need 3:1 against adjacent colours.