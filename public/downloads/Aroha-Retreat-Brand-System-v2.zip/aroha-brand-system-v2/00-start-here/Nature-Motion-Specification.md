# Aroha nature-motion specification

White (#FFFFFF) is the primary page and document surface. Ivory (#FAF7EF) is optional.
Neither is baked into exported icon artwork. The surface comparison is a static preview choice.

| Pattern | Purpose | Timing | Properties |
| --- | --- | --- | --- |
| Leaf settle | Spatial consistency, occasional entry | 240ms | translateY -8px to 0; rotate -2deg to 0; opacity 0 to 1 |
| Seed unfold | New panel state | 240ms | scale .96 to 1; translateY 6px to 0; opacity 0 to 1; origin at base |
| Water response | Pointer feedback | 140ms press, 220ms rings | button scale .98; ring scale .95 to 1.6 with opacity .55 to 0 |
| Path reveal | Indicate a next step | 200ms, 30ms segment stagger | translateX -6px to 0; opacity 0 to 1 |

All use cubic-bezier(.23,1,.32,1), a strong ease-out. No UI action waits for the animation.
No animation uses width, height, padding, margins, moving shadows, stroke-dashoffset or a JS frame loop.
CSS transitions retarget from the current state for production hover/press/reveal interactions.
The explanatory WAAPI samples intentionally restart on Replay, cancel any previous preview and stop at rest.
Keyboard-triggered actions show the final state immediately. OS reduced motion uses opacity only at 150ms.
When preview motion is unchecked, or the tab is hidden, owned animations are cancelled.
Hover movement is restricted to hover-capable fine pointers. Avoid decorative animation of reading content.
No autoplay, infinite loop, parallax, logo distortion, mandatory nature ornament or staggered form fields.

## Files
06-system/nature-motion.css: reusable production classes and exact easing/duration tokens.
06-system/nature-motion.js: explicitly controlled reference-page demos.
06-system/nature-motion-tokens.json: machine-readable specification and application gates.
00-start-here/Nature-Motion.html: keyboard-accessible live demonstrations and surface comparison.

## Acceptance
Check every Play control, Stop, surface switch, opt-out, repeated activation, keyboard focus and tab hiding.
Emulate OS reduced motion and inspect that no transform animation remains.
Review at normal speed and a slowed timeline; record on a mid-range touch device before product deployment.
Desktop preview and source inspection do not certify device frame rate or native launcher behaviour.
