AROHA RETREAT / BRAND SYSTEM V2

START: 00-start-here/Brand-Standards.html or Aroha-Brand-Standards-v2.pdf.
FAVICON: 03-digital/web/favicon.ico + favicon-adaptive.svg + favicon-96.png.
ICON ONLY: 02-icons/full/ (48px+) and 02-icons/micro/ (16-32px).
LANGUAGES: 01-logos/english, kannada, bilingual.
LAYOUTS: full, primary, horizontal, wordmark. Four colour modes each.
All icon artwork has transparent negative space. No opaque icon bitmap is included.
White variants need a dark preview surface. Do not use a detailed full logo as a favicon.
TYPOGRAPHY: Lora, Source Sans 3, Noto Serif Kannada, Noto Sans Kannada.
Font files, webfonts, licences, CSS and design tokens are bundled.
Android background is an independent optional platform resource, separate from transparent art.
Generic CMYK files require printer colour management and a physical proof.
This v2 package supersedes v1. See the handbook for platform and native format limitations.

SURFACE: White is primary; ivory is optional. Icons remain transparent.
MOTION: 00-start-here/Nature-Motion.html, with executable CSS/JS, tokens and reduced-motion rules.
