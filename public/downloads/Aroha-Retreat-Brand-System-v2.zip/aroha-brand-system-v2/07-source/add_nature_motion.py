"""Adds white-first nature motion samples and specifications to the v2 release."""
from pathlib import Path
import json
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
import pymupdf

def build_motion(out):
    def save(path,data):
        p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data);return p
    motion={
        'leafSettle':{'purpose':'Spatial consistency / occasional content entrance','durationMs':240,'easing':'cubic-bezier(0.23,1,0.32,1)','from':'translateY(-8px) rotate(-2deg)','to':'translateY(0) rotate(0deg)','opacity':[0,1]},
        'seedUnfold':{'purpose':'State indication / occasional card or section reveal','durationMs':240,'easing':'cubic-bezier(0.23,1,0.32,1)','from':'translateY(6px) scale(0.96)','to':'translateY(0) scale(1)','origin':'50% 100%','opacity':[0,1]},
        'waterResponse':{'purpose':'Pointer press feedback','pressDurationMs':140,'ringDurationMs':220,'easing':'cubic-bezier(0.23,1,0.32,1)','pressScale':0.98,'ringScale':[0.95,1.6],'opacity':[0.55,0]},
        'pathReveal':{'purpose':'State indication / reveal a short journey or next step','durationMs':200,'staggerMs':30,'easing':'cubic-bezier(0.23,1,0.32,1)','from':'translateX(-6px)','to':'translateX(0)','opacity':[0,1]},
        'policy':{'autoplay':False,'loop':False,'maxConcurrentPreviews':1,'keyboard':'Instant final state','reducedMotion':'Optional opacity-only 150ms; no movement','hiddenTab':'Cancel owned animations','production':'Reading content, form keystrokes and high-frequency navigation stay still'}
    }
    css='''/* Nature motion v2. Only transform and opacity are animated. */
:root{--ease-out:cubic-bezier(.23,1,.32,1);--ease-in-out:cubic-bezier(.77,0,.175,1);--motion-press:140ms;--motion-reveal:240ms;--motion-path:200ms;--motion-ring:220ms;--surface:#FFFFFF;--surface-warm:#FAF7EF}
/* Apply .nature-enter to an occasional, already-labelled content region. */
.nature-enter{opacity:0;transform:translateY(6px) scale(.96);transform-origin:50% 100%;transition:transform var(--motion-reveal) var(--ease-out),opacity var(--motion-reveal) var(--ease-out)}
.nature-enter.is-visible{opacity:1;transform:translateY(0) scale(1)}
.nature-button{transition:transform var(--motion-press) var(--ease-out)}
.nature-button:active:not(:focus-visible){transform:scale(.98)}
.nature-arrow{display:inline-block;transition:transform var(--motion-press) var(--ease-out)}
@media(hover:hover) and (pointer:fine){.nature-button:hover .nature-arrow{transform:translateX(2px)}}
@media(prefers-reduced-motion:reduce){.nature-enter{transform:none;transition:opacity 150ms ease}.nature-button,.nature-arrow{transition:none!important;transform:none!important}}
'''
    save(Path('06-system/nature-motion.css'),css)
    save(Path('06-system/nature-motion-tokens.json'),json.dumps(motion,indent=2))
    tokens=json.loads((out/'06-system/design-tokens.json').read_text());tokens['natureMotion']=motion
    save(Path('06-system/design-tokens.json'),json.dumps(tokens,indent=2))
    js='''/* Explicit preview playback. No external dependencies, autoplay or rAF loop. */
const ease='cubic-bezier(.23,1,.32,1)';
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
const owned=new Set();
const enabled=document.querySelector('#motion-enabled');
const status=document.querySelector('#motion-status');
function stopAll(){for(const a of owned)a.cancel();owned.clear();}
function animate(target,frames,options){const a=target.animate(frames,{easing:ease,...options});owned.add(a);a.finished.catch(()=>{}).finally(()=>owned.delete(a));return a;}
function announce(message){status.textContent=message;}
document.querySelectorAll('[data-play]').forEach(button=>button.addEventListener('click',event=>{
  stopAll();
  const card=button.closest('[data-effect]');const effect=card.dataset.effect;
  const art=card.querySelector('.motion-art');
  if(!enabled.checked||event.detail===0){announce(button.textContent.trim()+': final state shown without movement.');return;}
  if(reduced.matches||document.querySelector('#reduced-preview').checked){animate(art,[{opacity:.45},{opacity:1}],{duration:150});announce('Reduced motion: a gentle fade replaces movement.');return;}
  let last;
  if(effect==='leaf')last=animate(art,[{transform:'translateY(-8px) rotate(-2deg)',opacity:0},{transform:'translateY(0px) rotate(0deg)',opacity:1}],{duration:240});
  if(effect==='seed'){art.style.transformOrigin='50% 100%';last=animate(art,[{transform:'translateY(6px) scale(.96)',opacity:0},{transform:'translateY(0px) scale(1)',opacity:1}],{duration:240});}
  if(effect==='water'){
    for(const [i,ring] of [...card.querySelectorAll('.water-ring')].entries())last=animate(ring,[{transform:'scale(.95)',opacity:.55},{transform:'scale(1.6)',opacity:0}],{duration:220,delay:i*30});
  }
  if(effect==='path')for(const [i,segment] of [...card.querySelectorAll('.path-segment')].entries())last=animate(segment,[{transform:'translateX(-6px)',opacity:0},{transform:'translateX(0px)',opacity:1}],{duration:200,delay:i*30});
  announce(button.textContent.trim()+': playing once.');
  if(last)last.finished.then(()=>announce(button.textContent.trim()+': complete.')).catch(()=>{});
}));
document.querySelector('#stop-motion').addEventListener('click',()=>{stopAll();announce('Preview stopped. All artwork is at rest.');});
enabled.addEventListener('change',()=>{stopAll();announce(enabled.checked?'Preview enabled. Press a Play button to begin.':'Motion disabled. Artwork stays at rest.');});
document.querySelector('#reduced-preview').addEventListener('change',()=>{stopAll();announce('Reduced-motion preview setting updated.');});
reduced.addEventListener('change',()=>{stopAll();announce(reduced.matches?'System reduced-motion setting detected.':'System movement preference restored.');});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAll();});
document.querySelectorAll('button[data-surface]').forEach(button=>button.addEventListener('click',()=>{
 document.body.dataset.surface=button.dataset.surface;
 document.querySelectorAll('button[data-surface]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
}));
'''
    save(Path('06-system/nature-motion.js'),js)
    leaf='''<svg class="motion-art" viewBox="0 0 160 120" width="160" height="120" role="img" aria-label="A leaf settling"><path d="M46 99 C24 63 46 28 121 15 C108 45 122 82 65 99 C81 67 88 46 101 32 C74 53 59 76 46 99Z" fill="#60833D"/><path d="M42 108 Q63 68 100 33" fill="none" stroke="#163E2D" stroke-width="3" stroke-linecap="round"/></svg>'''
    seed='''<svg class="motion-art" viewBox="0 0 160 120" width="160" height="120" role="img" aria-label="A seed unfolding"><path d="M80 104 L80 54" fill="none" stroke="#163E2D" stroke-width="5" stroke-linecap="round"/><path d="M80 76 C46 82 32 61 34 41 C61 40 82 50 80 76Z M80 59 C79 27 101 18 128 20 C126 44 109 62 80 59Z" fill="#60833D"/><path d="M52 106 Q80 98 108 106" fill="none" stroke="#86613B" stroke-width="3" stroke-linecap="round"/></svg>'''
    water='''<div class="motion-art water" role="img" aria-label="Water response rings"><span class="water-ring"></span><span class="water-ring"></span><span class="water-centre"></span></div>'''
    path='''<svg class="motion-art" viewBox="0 0 200 120" width="200" height="120" role="img" aria-label="A path revealing its next step"><g fill="none" stroke="#163E2D" stroke-width="4" stroke-linecap="round"><path class="path-segment" d="M28 92 Q42 90 60 72"/><path class="path-segment" d="M66 67 Q100 30 126 47"/><path class="path-segment" d="M133 51 Q151 63 170 29"/></g><g fill="#60833D"><circle cx="28" cy="92" r="6"/><circle cx="170" cy="29" r="6"/></g></svg>'''
    definitions=[('leaf','Leaf settle',leaf,'240 ms / ease-out','Occasional content entrance. A short descent and two-degree turn settle into place.'),('seed','Seed unfold',seed,'240 ms / ease-out','A new section or card arrives from 96% scale, anchored at its base.'),('water','Water response',water,'140 ms press / 220 ms ring','Immediate pointer feedback with two restrained, fading rings. Never a loading indicator.'),('path','Path reveal',path,'200 ms / 30 ms stagger','A short route or next step becomes legible in sequence. No moving reading text.')]
    cards=''.join(f'<article class="motion-card" data-effect="{key}"><div class="motion-stage">{art}</div><span class="eyebrow">{timing}</span><h2>{title}</h2><p>{purpose}</p><button class="nature-button" data-play>Play {title.lower()} <span class="nature-arrow" aria-hidden="true">→</span></button></article>' for key,title,art,timing,purpose in definitions)
    html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aroha / Nature motion</title><link rel="icon" type="image/svg+xml" href="../03-digital/web/favicon-adaptive.svg"><link rel="stylesheet" href="../06-system/brand.css"><link rel="stylesheet" href="../06-system/nature-motion.css"><style>
*{box-sizing:border-box}body{margin:0;background:#fff}body[data-surface="warm"]{background:#FAF7EF}main{max-width:1200px;padding:48px 28px 88px;margin:auto}header{max-width:900px}h1{font-size:clamp(40px,5vw,64px);line-height:1.12;margin:24px 0}h2{font-size:26px;line-height:1.25}.eyebrow{font-size:13px;letter-spacing:.1em;font-weight:600}.intro{font-size:22px;max-width:780px}.controls{display:flex;align-items:center;flex-wrap:wrap;gap:16px;margin:28px 0}.controls button{background:white;color:#163E2D;border:1px solid #163E2D}.controls button[aria-pressed="true"]{background:#163E2D;color:#fff}.controls label{display:flex;align-items:center;gap:10px}.controls input{width:20px;height:20px;accent-color:#163E2D}.motion-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px;margin-top:32px}.motion-card{display:flex;align-items:flex-start;flex-direction:column;border:1px solid #DDE5D7;border-radius:12px;padding:28px;background:#fff;overflow:hidden}.motion-card p{flex:1}.motion-stage{height:150px;width:100%;display:flex;align-items:center;justify-content:center;margin-bottom:16px;background:#fff}.motion-art{display:block;flex:none}.water{position:relative;width:160px;height:120px}.water-ring{position:absolute;left:45px;top:25px;width:70px;height:70px;border:2px solid #60833D;border-radius:50%;opacity:0}.water-centre{position:absolute;width:14px;height:14px;left:73px;top:53px;border-radius:50%;background:#163E2D}a{color:#163E2D;text-underline-offset:4px}.guide{border-top:1px solid #DDE5D7;margin-top:48px;padding-top:24px}.status{min-height:28px;font-size:16px}code{font-size:15px}li{margin:12px 0}pre{white-space:pre-wrap;border:1px solid #DDE5D7;padding:20px;font-size:14px}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:12px;border-bottom:1px solid #DDE5D7}nav a{display:inline-flex;align-items:center;min-height:48px}@media(max-width:700px){main{padding:28px 20px 64px}.motion-grid{grid-template-columns:1fr}.motion-card{padding:24px}.controls{gap:12px}h1{font-size:40px}.intro{font-size:20px}}
</style><main><nav><a href="Brand-Standards.html">← Brand standards</a></nav><header><div class="eyebrow">AROHA RETREAT / NATURE MOTION / V2</div><h1>Movement with a<br>natural rhythm.</h1><p class="intro">White is the primary surface. Nature comes through proportion, type, colour accents and purposeful movement—not through a mandatory tinted background.</p><p>Four finite motion patterns for occasional reveals and clear feedback. Nothing autoplays, loops or delays a task.</p></header><div class="controls" aria-label="Preview settings"><button data-surface="white" aria-pressed="true">White surface</button><button data-surface="warm" aria-pressed="false">Compare warm ivory</button><label><input type="checkbox" id="motion-enabled" checked>Enable preview motion</label><label><input type="checkbox" id="reduced-preview">Preview reduced motion</label><button id="stop-motion">Stop motion</button></div><p class="status" id="motion-status" role="status" aria-live="polite">Choose a Play button. Keyboard activation shows the final state instantly.</p><section class="motion-grid" aria-label="Nature motion examples">'''+cards+'''</section><section class="guide"><h2>Where the movement belongs</h2><ul><li><strong>Leaf settle:</strong> an occasional section introduction or experience card appearing after a deliberate action.</li><li><strong>Seed unfold:</strong> a new, already-labelled panel becoming available. No changing layout dimensions.</li><li><strong>Water response:</strong> pointer feedback. Keep the actual button response immediate; ring effects are decorative.</li><li><strong>Path reveal:</strong> a short itinerary or next step. Never obscure progress or animate data someone is reading.</li></ul><p>Keep menus, form keystrokes and frequent keyboard actions still. Logo files and icons remain static transparent assets; these patterns are for interface and explanatory content, not a continuously moving brand mark.</p><h2>Accessibility and interruption</h2><p>System reduced motion replaces movement with a 150 ms opacity fade. The checkbox disables the preview entirely. Keyboard-triggered controls show the final state immediately. Starting another sample cancels the previous one; Stop motion and hiding the tab cancel owned animations. No infinite loops, automatic scroll reveals, parallax or flashing.</p><h2>Implementation</h2><p><a href="../06-system/nature-motion.css">CSS</a> · <a href="../06-system/nature-motion.js">Preview controller</a> · <a href="../06-system/nature-motion-tokens.json">Motion tokens</a> · <a href="Nature-Motion-Specification.md">Specification</a></p><pre>&lt;link rel="stylesheet" href="/brand/brand.css"&gt;
&lt;link rel="stylesheet" href="/brand/nature-motion.css"&gt;

&lt;section class="nature-enter"&gt;Labelled content&lt;/section&gt;
&lt;!-- Add is-visible after a deliberate action. With no JS, omit nature-enter. --&gt;
&lt;button class="nature-button"&gt;Explore &lt;span class="nature-arrow" aria-hidden="true"&gt;→&lt;/span&gt;&lt;/button&gt;</pre><p>The preview controller targets this page’s demo markup. For production, reuse the CSS and tokens within the application’s own component state. Validate touch, keyboard, reduced motion and performance on a representative phone before shipping.</p></section></main><script defer src="../06-system/nature-motion.js"></script></html>'''
    save(Path('00-start-here/Nature-Motion.html'),html)
    guide=out/'00-start-here/Brand-Standards.html';text=guide.read_text()
    text=text.replace('Ivory is the main surface.','White is the primary surface; ivory is an optional warm alternative.')
    if '<a href="Nature-Motion.html">Nature motion</a>' not in text:text=text.replace('<a href="#sources">Sources</a>','<a href="Nature-Motion.html">Nature motion</a><a href="#sources">Sources</a>')
    if 'Open the interactive nature-motion library' not in text:text=text.replace('<p class="intro">','<p><a href="Nature-Motion.html">Open the interactive nature-motion library →</a></p><p class="intro">',1)
    guide.write_text(text)
    readme=out/'README.txt'
    if 'SURFACE:' not in readme.read_text():readme.write_text(readme.read_text()+'\nSURFACE: White is primary; ivory is optional. Icons remain transparent.\nMOTION: 00-start-here/Nature-Motion.html, with executable CSS/JS, tokens and reduced-motion rules.\n')
    spec='''# Aroha nature-motion specification

White (#FFFFFF) is the primary page and document surface. Ivory (#FAF7EF) is optional.
Neither is baked into exported icon artwork. The surface comparison is a static preview choice.

| Pattern | Purpose | Timing | Properties |
| --- | --- | --- | --- |
| Leaf settle | Spatial consistency, occasional entry | 240ms | translateY -8px to 0; rotate -2deg to 0; opacity 0 to 1 |
| Seed unfold | New panel state | 240ms | scale .96 to 1; translateY 6px to 0; opacity 0 to 1; origin at base |
| Water response | Pointer feedback | 140ms press, 220ms rings | button scale .98; ring scale .95 to 1.6 with opacity .55 to 0 |
| Path reveal | Indicate a next step | 200ms, 30ms segment stagger | translateX -6px to 0; opacity 0 to 1 |

All use cubic-bezier(.23,1,.32,1), a strong ease-out. No UI action waits for the animation.
No animation uses width, height, padding, margins, moving shadows, stroke-dashoffset or a JS frame loop.
CSS transitions retarget from the current state for production hover/press/reveal interactions.
The explanatory WAAPI samples intentionally restart on Replay, cancel any previous preview and stop at rest.
Keyboard-triggered actions show the final state immediately. OS reduced motion uses opacity only at 150ms.
When preview motion is unchecked, or the tab is hidden, owned animations are cancelled.
Hover movement is restricted to hover-capable fine pointers. Avoid decorative animation of reading content.
No autoplay, infinite loop, parallax, logo distortion, mandatory nature ornament or staggered form fields.

## Files
06-system/nature-motion.css: reusable production classes and exact easing/duration tokens.
06-system/nature-motion.js: explicitly controlled reference-page demos.
06-system/nature-motion-tokens.json: machine-readable specification and application gates.
00-start-here/Nature-Motion.html: keyboard-accessible live demonstrations and surface comparison.

## Acceptance
Check every Play control, Stop, surface switch, opt-out, repeated activation, keyboard focus and tab hiding.
Emulate OS reduced motion and inspect that no transform animation remains.
Review at normal speed and a slowed timeline; record on a mid-range touch device before product deployment.
Desktop preview and source inspection do not certify device frame rate or native launcher behaviour.
'''
    save(Path('00-start-here/Nature-Motion-Specification.md'),spec)

    # A two-page motion supplement also becomes pages 12-13 of the main handbook.
    pdf=out/'00-start-here/Nature-Motion-Specification.pdf';c=canvas.Canvas(str(pdf),pagesize=(842,595))
    c.setTitle('Aroha Retreat / Nature motion specification')
    def page(num,title,subtitle):
        c.setFillColor(HexColor('#FFFFFF'));c.rect(0,0,842,595,fill=1,stroke=0);c.setFillColor(HexColor('#163E2D'))
        c.setFont('SourceSans3-600',10);c.drawString(44,555,'AROHA RETREAT / NATURE MOTION / V2')
        c.setFont('Lora-500',30);c.drawString(44,500,title);c.setFont('SourceSans3-400',12);c.drawString(44,475,subtitle)
        c.setStrokeColor(HexColor('#CCD3C8'));c.line(44,40,798,40);c.setFont('SourceSans3-400',9);c.drawString(44,24,'WHITE-FIRST SURFACES / TRANSPARENT ICONS');c.drawRightString(798,24,str(num))
    def lines(x,y,items,size=12,leading=20):
        c.setFont('SourceSans3-400',size);c.setFillColor(HexColor('#163E2D'))
        for item in items:c.drawString(x,y,item);y-=leading
    page(12,'White space. Natural movement.','White is primary. Warm ivory is optional. Exported icon backgrounds stay transparent.')
    lines(44,425,['Motion has a purpose: feedback, spatial consistency or a clear state change.','Use nature as a timing and proportion reference, not as constant ornament.','', 'LEAF SETTLE / 240 ms','An occasional entrance settles through 8 px of vertical travel and two degrees of rotation.','', 'SEED UNFOLD / 240 ms','A panel arrives from 96% scale and 6 px below, anchored at its base.','', 'WATER RESPONSE / 140 ms press / 220 ms ring','Pointer press feedback is immediate. Decorative rings expand gently and fade.','', 'PATH REVEAL / 200 ms with 30 ms segment stagger','A short route or next step becomes legible in sequence without moving reading text.'])
    c.showPage();page(13,'Motion tokens & safeguards','Open Nature-Motion.html for working samples, surface comparison and opt-out controls.')
    lines(44,425,['Easing: cubic-bezier(0.23, 1, 0.32, 1). UI effects stay below 300 ms.','Properties: transform and opacity only. No layout animation or JavaScript frame loop.','CSS transitions handle interruptible production hover, press and reveal states.','WAAPI handles the deliberately replayable explanatory samples without a motion dependency.','', 'Keyboard: instant final state. Reduced motion: 150 ms opacity-only feedback.','Fine-pointer hover gating ships with the CSS. No touch hover transforms.','Stop control, motion opt-out and tab hiding cancel owned preview animations.','No autoplay, infinite loops, parallax, loading rings that imply false progress or moving form fields.','', 'Files: nature-motion.css, nature-motion.js and nature-motion-tokens.json in 06-system/.','Keep production component state and accessibility semantics in the application.','Validate normal speed, interruptions, keyboard, touch and reduced motion before release.','Desktop checks do not establish frame-rate performance on a representative phone.'])
    c.showPage();c.save()
    main=out/'00-start-here/Aroha-Brand-Standards-v2.pdf';d=pymupdf.open(main)
    if len(d)>11:d.select(list(range(11)))
    m=pymupdf.open(pdf);d.insert_pdf(m);temp=main.with_suffix('.new.pdf');d.save(temp);d.close();m.close();temp.replace(main)
