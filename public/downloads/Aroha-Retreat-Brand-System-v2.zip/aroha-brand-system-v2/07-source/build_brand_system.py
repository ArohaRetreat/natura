"""Aroha v2: deterministic vector identity, transparent icon system and handbook.
Run with --input pointing to a folder containing fonts/ and source/trace.svg.
Dependencies: pillow cairosvg svglib reportlab fonttools brotli uharfbuzz pymupdf.
"""
from pathlib import Path
import argparse, copy, csv, hashlib, io, json, re, shutil, zipfile
import xml.etree.ElementTree as ET
import cairosvg, uharfbuzz as hb
from PIL import Image
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont as RLFont
from reportlab.lib.colors import HexColor, CMYKColor
from reportlab.graphics import renderPDF, renderPS
from svglib.svglib import svg2rlg

args=argparse.ArgumentParser();args.add_argument('--input',type=Path,required=True);args.add_argument('--output',type=Path,required=True);a=args.parse_args()
OUT=a.output;OUT.mkdir(parents=True,exist_ok=True)
NS='http://www.w3.org/2000/svg';ET.register_namespace('',NS)
G='#163E2D';L='#60833D';B='#86613B';I='#FAF7EF';M='#DDE5D7'
def el(tag,**attrs):return ET.Element('{%s}%s'%(NS,tag),{k:str(v) for k,v in attrs.items()})
def save(path,data):
    p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(data if isinstance(data,bytes) else data.encode());return p
def xml(node):return ET.tostring(node,encoding='utf-8',xml_declaration=True)
def root(w,h,title):
    r=el('svg',viewBox=f'0 0 {w} {h}',width=w,height=h,role='img');t=el('title');t.text=title;r.append(t);return r
raw=ET.parse(a.input/'source/trace.svg').getroot()
parts=[]
for p in raw:
    x,y=map(float,re.findall(r'-?\d+(?:\.\d+)?',p.get('transform')))
    q=copy.deepcopy(p);q.set('fill-rule','evenodd');q.set('fill',L if x>1050 and y<400 else G)
    parts.append((x,y,q))
def select(parent,pred,transform='',ink=None):
    group=el('g',transform=transform) if transform else el('g')
    for x,y,p in parts:
        if pred(x,y):
            q=copy.deepcopy(p)
            if ink:q.set('fill',ink)
            group.append(q)
    parent.append(group);return group
def mark(parent,x,y,w,detail='full',ink=None):
    # Micro removes the inner heart, leaf and thin ground swoosh.
    vb=(480,80,620,460) if detail=='full' else (480,80,510,410)
    sc=w/vb[2]
    pred=(lambda px,py:py<540) if detail=='full' else (lambda px,py:180<py<250 and px<1000)
    group=select(parent,pred,f'translate({x-vb[0]*sc} {y-vb[1]*sc}) scale({sc})',ink)
    if detail=='micro':
        for path in group:
            path.set('stroke',ink or G);path.set('stroke-width','8');path.set('stroke-linejoin','round')
        group.append(el('circle',cx=770,cy=132,r=40,fill=ink or G))
    return group

# Bundle the four unmodified OFL families, plus reproducible static print instances.
FONTS={};font_manifest=[]
for family in ['Lora','SourceSans3','NotoSerifKannada','NotoSansKannada']:
    src=a.input/'fonts'/family
    for f in src.iterdir():save(Path('04-typography/fonts')/family/f.name,f.read_bytes())
    vf=TTFont(src/f'{family}-Variable.ttf')
    for weight in [400,500,600]:
        loc={'wght':weight}
        if 'wdth' in [ax.axisTag for ax in vf['fvar'].axes]:loc['wdth']=100
        inst=instantiateVariableFont(vf,loc,inplace=False)
        file=OUT/'04-typography/fonts'/family/f'{family}-{weight}.ttf';inst.save(file)
        FONTS[(family,weight)]=file
        pdfmetrics.registerFont(RLFont(f'{family}-{weight}',str(file)))
    web=TTFont(src/f'{family}-Variable.ttf');web.flavor='woff2';web.save(OUT/'04-typography/fonts'/family/f'{family}-Variable.woff2')
    font_manifest.append({'family':family,'license':'SIL Open Font License 1.1','source':f'https://github.com/google/fonts/tree/main/ofl/'+{'Lora':'lora','SourceSans3':'sourcesans3','NotoSerifKannada':'notoserifkannada','NotoSansKannada':'notosanskannada'}[family]})

font_cache={}
def text(parent,string,cx,baseline,size,family='SourceSans3',weight=400,fill=G,tracking=0,anchor='middle'):
    key=(family,weight)
    if key not in font_cache:
        data=FONTS[key].read_bytes();face=hb.Face(data);f=hb.Font(face);hb.ot_font_set_funcs(f)
        font_cache[key]=(TTFont(io.BytesIO(data)),f,face.upem)
    ft,hfont,upem=font_cache[key];buf=hb.Buffer();buf.add_str(string);buf.guess_segment_properties();hb.shape(hfont,buf,{'kern':True})
    assert all(g.codepoint for g in buf.glyph_infos),f'Unsupported text: {string}'
    sc=size/upem;advance=sum(pos.x_advance*sc for pos in buf.glyph_positions)+tracking*max(0,len(buf.glyph_infos)-1)
    offset=cx-advance/2 if anchor=='middle' else cx
    group=el('g',fill=fill,**{'aria-label':string});gs=ft.getGlyphSet();order=ft.getGlyphOrder();posx=0
    for info,pos in zip(buf.glyph_infos,buf.glyph_positions):
        pen=SVGPathPen(gs);gs[order[info.codepoint]].draw(pen)
        if pen.getCommands():group.append(el('path',d=pen.getCommands(),transform=f'translate({offset+posx+pos.x_offset*sc} {baseline-pos.y_offset*sc}) scale({sc} {-sc})'))
        posx+=pos.x_advance*sc+tracking
    parent.append(group)
    return advance
def brandname(parent,lang,baseline=660):
    if lang=='english':text(parent,'AROHA',600,baseline,128,'Lora',600,tracking=7)
    elif lang=='kannada':select(parent,lambda x,y:540<y<700 and x<800,f'translate(79 {baseline-685})',G)
    else:
        select(parent,lambda x,y:540<y<700 and x<800,f'translate(-150 {baseline-685})',G)
        text(parent,'AROHA',880,baseline,108,'Lora',600,tracking=5)
        parent.append(el('rect',x=646,y=baseline-110,width=3,height=125,rx=1.5,fill=B))
def tagline(parent,lang,y=850):
    if lang=='english':text(parent,'Return to Yourself',600,y,42)
    elif lang=='kannada':select(parent,lambda x,py:800<py<880 and x>820,f'translate(-407 {y-850})',G)
    else:
        text(parent,'Return to Yourself',380,y,34)
        parent.append(el('circle',cx=610,cy=y-12,r=4,fill=B))
        select(parent,lambda x,py:800<py<880 and x>820,f'translate(95 {y-674}) scale(0.8)',G)
def logo(lang,layout,ink=None):
    heights={'full':1040,'primary':820,'wordmark':340,'horizontal':340}
    r=root(1000 if layout=='horizontal' else 1200,heights[layout],f'Aroha Retreat / {lang} / {layout}')
    if layout in ['full','primary']:
        mark(r,300,40,600);brandname(r,lang)
        if lang!='kannada':text(r,'RETREAT',600,750,42,weight=600,fill=B,tracking=15)
        if layout=='full':
            tagline(r,lang,865 if lang!='kannada' else 810)
            if lang!='kannada':text(r,'NATURE  |  MEDITATION  |  FARM LIFE',600,975,24,weight=600,tracking=5)
    elif layout=='wordmark':
        grp=el('g',transform='translate(0 -445)');r.append(grp);brandname(grp,lang)
        if lang!='kannada':text(grp,'RETREAT',600,745,38,weight=600,fill=B,tracking=15)
    else:
        mark(r,35,40,325)
        grp=el('g',transform='translate(372 -155) scale(0.53)' if lang=='bilingual' else 'translate(90 -445)');r.append(grp);brandname(grp,lang)
        if lang!='kannada':text(grp,'RETREAT',600,745,42,weight=600,fill=B,tracking=15)
    if ink:
        for node in r.iter():
            if node.get('fill'):node.set('fill',ink)
    return r

assets=[]
def exported(path,kind,purpose,**more):assets.append({'path':str(path),'kind':kind,'purpose':purpose,**more})
def svg_exports(node,stem,purpose,raster_widths=(600,1200,2400),tiff=False):
    data=xml(node);sp=save(str(stem)+'.svg',data);exported(sp.relative_to(OUT),'SVG',purpose,transparent=True)
    pdf=save(str(stem)+'.pdf',cairosvg.svg2pdf(bytestring=data));exported(pdf.relative_to(OUT),'RGB vector PDF',purpose)
    drawing=svg2rlg(io.BytesIO(data));eps=OUT/(str(stem)+'.eps');renderPS.drawToFile(drawing,str(eps));exported(eps.relative_to(OUT),'RGB vector EPS',purpose)
    for width in raster_widths:
        png=save(str(stem)+f'-{width}.png',cairosvg.svg2png(bytestring=data,output_width=width));exported(png.relative_to(OUT),'PNG',purpose,width=width,transparent=True)
    # TIFF and WebP are format conversions of the same transparent master.
    im=Image.open(io.BytesIO(cairosvg.svg2png(bytestring=data,output_width=max(raster_widths))))
    if tiff:
        tp=OUT/(str(stem)+'.tiff');im.save(tp,compression='tiff_lzw',dpi=(300,300));exported(tp.relative_to(OUT),'RGBA TIFF',purpose,transparent=True)
    wp=OUT/(str(stem)+'.webp');im.save(wp,lossless=True);exported(wp.relative_to(OUT),'WebP',purpose,transparent=True)
for lang in ['english','kannada','bilingual']:
    for layout in ['full','primary','horizontal','wordmark']:
        for mode,ink in [('colour',None),('forest',G),('black','#000000'),('white','#FFFFFF')]:
            svg_exports(logo(lang,layout,ink),Path('01-logos')/lang/f'aroha-{layout}-{mode}',f'{lang} {layout} logo',tiff=mode=='colour')
        # Separate generic CMYK print master, without claiming a press profile.
        d=svg2rlg(io.BytesIO(xml(logo(lang,layout))))
        def convert(n):
            for key in ['fillColor','strokeColor']:
                col=getattr(n,key,None)
                if col is not None and hasattr(col,'red'):
                    vals=(col.red,col.green,col.blue);k=1-max(vals)
                    cmy=[(1-v-k)/(1-k) if k<1 else 0 for v in vals]
                    setattr(n,key,CMYKColor(*cmy,k))
            for ch in getattr(n,'contents',[]):convert(ch)
        convert(d)
        for ext,renderer in [('pdf',renderPDF),('eps',renderPS)]:
            p=OUT/'05-print'/lang/f'aroha-{layout}-CMYK-unprofiled.{ext}';p.parent.mkdir(parents=True,exist_ok=True);renderer.drawToFile(d,str(p));exported(p.relative_to(OUT),'Generic CMYK '+ext,'Printer conversion and physical proof required')

def icon(detail='micro',ink=G,adaptive=False):
    if adaptive:
        r=root(108,108,'Aroha / transparent adaptive foreground');mark(r,26,33,56,detail,ink)
    else:
        r=root(64,64,'Aroha / '+detail+' / icon only')
        if detail=='micro':mark(r,4,9,56,'micro',ink)
        else:mark(r,4,11,56,'full',ink)
    return r
for detail in ['full','micro']:
    for mode,ink in [('forest',G),('black','#000000'),('white','#FFFFFF')]:
        svg_exports(icon(detail,ink),Path('02-icons')/detail/f'aroha-icon-{mode}','Text-free transparent '+detail+' mark',raster_widths=(16,24,32,48,64,128,256,512,1024) if detail=='micro' else (48,64,128,256,512,1024),tiff=True)
# Full colour icon is separate from one-colour micro.
r=root(64,64,'Aroha / full colour icon');mark(r,4,11,56)
svg_exports(r,Path('02-icons/full/aroha-icon-colour'),'Full colour transparent emblem',raster_widths=(48,64,128,256,512,1024))

WEB=Path('03-digital/web');fav=icon()
save(WEB/'favicon.svg',xml(fav))
# SVG favicon can adapt to dark browser chrome; PNG and ICO remain explicit variants.
dark=copy.deepcopy(fav);style=el('style');style.text='@media (prefers-color-scheme:dark){g,path,circle{fill:#FAF7EF}}';dark.insert(0,style);save(WEB/'favicon-adaptive.svg',xml(dark))
for size in [16,32,48,64,96,192,512]:
    save(WEB/f'favicon-{size}.png',cairosvg.svg2png(bytestring=xml(fav),output_width=size))
for mode,ink in [('forest',G),('white','#FFFFFF')]:
    im=Image.open(io.BytesIO(cairosvg.svg2png(bytestring=xml(icon('micro',ink)),output_width=256)))
    im.save(OUT/WEB/f'favicon-{mode}.ico',sizes=[(16,16),(32,32),(48,48),(64,64)])
shutil.copy2(OUT/WEB/'favicon-forest.ico',OUT/WEB/'favicon.ico')
for size in [180,192,512]:save(WEB/f'icon-{size}.png',cairosvg.svg2png(bytestring=xml(icon('full')),output_width=size))
save(WEB/'site.webmanifest',json.dumps({'name':'Aroha Retreat','short_name':'Aroha','id':'/','start_url':'/','scope':'/','display':'standalone','background_color':'#FFFFFF','theme_color':G,'icons':[{'src':f'icon-{s}.png','sizes':f'{s}x{s}','type':'image/png','purpose':'any'} for s in [192,512]]},indent=2))
save(WEB/'head-snippet.html','''<!-- Copy the contents of 03-digital/web/ to /brand/ and add these tags. -->
<link rel="icon" href="/brand/favicon.ico" sizes="any">
<link rel="icon" href="/brand/favicon-adaptive.svg" type="image/svg+xml">
<link rel="icon" href="/brand/favicon-96.png" sizes="96x96" type="image/png">
<link rel="apple-touch-icon" href="/brand/icon-180.png">
<link rel="manifest" href="/brand/site.webmanifest">
<meta name="theme-color" content="#163E2D">
''')
AD=Path('03-digital/android/res')
for mode,ink in [('foreground',G),('monochrome','#000000')]:
    node=icon('full',ink,True);save(Path('03-digital/android')/f'{mode}-108.svg',xml(node))
    for size in [108,216,324,432]:save(Path('03-digital/android')/f'{mode}-{size}.png',cairosvg.svg2png(bytestring=xml(node),output_width=size))
    # Valid Android VectorDrawable: preserve each traced path and flatten transforms.
    from fontTools.svgLib.path import parse_path
    from fontTools.pens.transformPen import TransformPen
    vp=ET.Element('vector',{'xmlns:android':'http://schemas.android.com/apk/res/android','android:width':'108dp','android:height':'108dp','android:viewportWidth':'108','android:viewportHeight':'108'})
    # The full emblem is bounded inside 56 x 42 dp, centred in the safe circle.
    sc=56/620;tx=26-480*sc;ty=33-80*sc
    for px,py,p in parts:
        if py>=540:continue
        ox,oy=map(float,re.findall(r'-?\d+(?:\.\d+)?',p.get('transform')))
        pen=SVGPathPen(None);tp=TransformPen(pen,(sc,0,0,sc,tx+ox*sc,ty+oy*sc));parse_path(p.get('d'),tp)
        ET.SubElement(vp,'path',{'android:fillColor':ink,'android:fillType':'evenOdd','android:pathData':pen.getCommands()})
    save(AD/'drawable'/f'ic_launcher_{mode}.xml',ET.tostring(vp,encoding='utf-8',xml_declaration=True))
# Background is deliberately separate; no opaque icon bitmaps are exported.
save(AD/'values/colors.xml','<resources><color name="ic_launcher_background">#FFFFFF</color></resources>')
save(AD/'mipmap-anydpi-v26/ic_launcher.xml','''<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
  <background android:drawable="@color/ic_launcher_background"/>
  <foreground android:drawable="@drawable/ic_launcher_foreground"/>
</adaptive-icon>''')
save(AD/'mipmap-anydpi-v33/ic_launcher.xml','''<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
  <background android:drawable="@color/ic_launcher_background"/>
  <foreground android:drawable="@drawable/ic_launcher_foreground"/>
  <monochrome android:drawable="@drawable/ic_launcher_monochrome"/>
</adaptive-icon>''')
for size in [400,800,1024]:save(Path('03-digital/social')/f'avatar-transparent-{size}.png',cairosvg.svg2png(bytestring=xml(icon('full')),output_width=size))
for f in (OUT/'03-digital').rglob('*'):
    if f.is_file():exported(f.relative_to(OUT),f.suffix[1:].upper(),'Platform integration asset; see handbook',transparent=True if f.suffix in ['.png','.svg','.ico'] else '')

tokens={'version':'2.0.0','color':{'forest':G,'leaf':L,'bronze':B,'ivory':I,'mist':M,'white':'#FFFFFF'},'font':{'display.en':'Lora','body.en':'Source Sans 3','display.kn':'Noto Serif Kannada','body.kn':'Noto Sans Kannada'},'space':[4,8,12,16,24,32,48,64,96],'type':{'display':{'size':56,'line':64,'weight':500},'h1':{'size':40,'line':48,'weight':500},'h2':{'size':32,'line':40,'weight':500},'h3':{'size':24,'line':32,'weight':600},'body':{'size':18,'line':28,'weight':400},'bodySmall':{'size':16,'line':24,'weight':400},'label':{'size':16,'line':24,'weight':600},'caption':{'size':14,'line':20,'weight':400}},'motion':{'durationMs':180,'easing':'cubic-bezier(0.2,0,0,1)','reducedMotion':'disable nonessential transitions'},'interaction':{'minTargetPx':48,'focusRingPx':3}}
tokens['surface']={'default':'#FFFFFF','warmOptional':I,'icon':'transparent'}
tokens['motion']['easing']='cubic-bezier(0.23,1,0.32,1)'
save(Path('04-typography/font-manifest.json'),json.dumps(font_manifest,indent=2));save(Path('06-system/design-tokens.json'),json.dumps(tokens,indent=2))
css=''
for name,cssname in [('Lora','Lora'),('SourceSans3','Source Sans 3'),('NotoSerifKannada','Noto Serif Kannada'),('NotoSansKannada','Noto Sans Kannada')]:
    wrange='400 700' if name=='Lora' else '200 900' if name=='SourceSans3' else '100 900'
    css+=f'@font-face{{font-family:"{cssname}";src:url("../04-typography/fonts/{name}/{name}-Variable.woff2") format("woff2");font-weight:{wrange};font-style:normal;font-display:swap;}}\n'
css+=''' :root{--forest:#163E2D;--leaf:#60833D;--bronze:#86613B;--ivory:#FAF7EF;--mist:#DDE5D7;--display:"Lora",serif;--body:"Source Sans 3",sans-serif;--display-kn:"Noto Serif Kannada",serif;--body-kn:"Noto Sans Kannada",sans-serif;}
body{font-family:var(--body);font-size:18px;line-height:1.55;color:var(--forest);background:#FFFFFF}
h1,h2,h3{font-family:var(--display);font-weight:500;line-height:1.15;letter-spacing:-.015em}
:lang(kn){font-family:var(--body-kn);line-height:1.65;letter-spacing:normal}
h1:lang(kn),h2:lang(kn),h3:lang(kn){font-family:var(--display-kn);line-height:1.5;letter-spacing:normal}
button,input,select,textarea{font:inherit}button,.button{min-height:48px;min-width:48px;padding:12px 24px;border-radius:8px;background:var(--forest);color:var(--ivory);border:2px solid transparent;font-weight:600;cursor:pointer}
button:hover,.button:hover{background:#214F3A}button:disabled{opacity:.45;cursor:default}
:focus-visible{outline:3px solid var(--forest);outline-offset:4px}
h1{font-size:40px;line-height:48px}h2{font-size:32px;line-height:40px}h3{font-size:24px;line-height:32px;font-weight:600}
td,th{overflow-wrap:anywhere}.nav a{display:inline-flex;align-items:center;min-height:48px}
.display{font:500 56px/1.15 var(--display)}.body-small{font-size:16px;line-height:24px}.caption{font-size:14px;line-height:20px}.label{font-weight:600;font-size:16px}
@media(prefers-reduced-motion:no-preference){button{transition:background-color 180ms cubic-bezier(.23,1,.32,1)}}
'''
save(Path('06-system/brand.css'),css)

def colour_spec(hx):
    rgb=[int(hx[j:j+2],16) for j in (1,3,5)];unit=[v/255 for v in rgb];k=1-max(unit)
    return {'hex':hx,'rgb':rgb,'genericCmykPercent':[round(100*(1-v-k)/(1-k)) if k<1 else 0 for v in unit]+[round(100*k)]}
def luminance(hx):
    v=[int(hx[j:j+2],16)/255 for j in (1,3,5)];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
    return sum(a*b for a,b in zip(v,[.2126,.7152,.0722]))
contrasts={name+'-on-'+surface:round((max(luminance(hx),luminance(bg))+.05)/(min(luminance(hx),luminance(bg))+.05),3) for name,hx in [('forest',G),('leaf',L),('bronze',B)] for surface,bg in [('white','#FFFFFF'),('ivory',I)]}
save(Path('06-system/palette-specifications.json'),json.dumps({'palette':{key:colour_spec(hx) for key,hx in tokens['color'].items()},'contrastRatios':contrasts,'printNote':'CMYK estimates are unprofiled; printer must convert using the press and paper profile.'},indent=2))

sources=[('Material Design / product icon principles','https://m1.material.io/style/icons.html','Historical Material reference: simple silhouettes, keylines, optical consistency; no legacy shadows adopted.'),('Material Design 3 / icon overview','https://m3.material.io/styles/icons/overview','Current landing page; JavaScript-only in text fetch. Detailed dimensions taken from Android documentation.'),('Android adaptive icon specification','https://developer.android.com/develop/ui/compose/system/icon_design_adaptive','108dp layers, safe content placement, separate foreground/background and monochrome.'),('Google Play icon specification','https://developer.android.com/distribute/google-play/resources/icon-design-specifications','512px square sRGB PNG; platform mask and shadows. Store upload needs a separate opaque composite.'),('Google Search favicon guidance','https://developers.google.com/search/docs/appearance/favicon-in-search','Square, stable URL, crawlable; 96px PNG supplied for search.'),('Lora / official description','https://raw.githubusercontent.com/google/fonts/main/ofl/lora/DESCRIPTION.en_us.html','Calligraphic curves, moderate contrast, screen and print use.'),('Source Sans 3 / official description','https://raw.githubusercontent.com/google/fonts/main/ofl/sourcesans3/DESCRIPTION.en_us.html','Interface-oriented sans serif.'),('Noto Serif Kannada / official metadata','https://raw.githubusercontent.com/google/fonts/main/ofl/notoserifkannada/METADATA.pb','Kannada serif family and OFL license.'),('Noto Sans Kannada / official metadata','https://raw.githubusercontent.com/google/fonts/main/ofl/notosanskannada/METADATA.pb','Kannada sans family and OFL license.')]
sources.extend([('WCAG 2.2 / text contrast','https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html','Normal text 4.5:1; large text 3:1. Logos are exempt, but interface text is not.'),('WCAG 2.2 / non-text contrast','https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html','Meaningful control boundaries and graphics need 3:1 against adjacent colours.')])
save(Path('00-start-here/Sources.md'),'# Sources checked 31 October 2026\n\n'+'\n\n'.join(f'[{title}]({url})\n\n{note}' for title,url,note in sources))

# Standalone HTML handbook, with local fonts, responsive components, and actual-size proofs.
cards=''
for lang in ['english','kannada','bilingual']:
    cards+=f'<article class="card"><img class="logo" src="../01-logos/{lang}/aroha-horizontal-colour.svg" alt="Aroha {lang} horizontal logo"><h3>{lang.title()}</h3><p>Full, primary, horizontal and wordmark. Colour, forest, black and white versions.</p></article>'
html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aroha brand standards v2</title><link rel="stylesheet" href="../06-system/brand.css"><style>
*{box-sizing:border-box}body{margin:0}main{max-width:1200px;margin:auto;padding:48px 28px 96px}header{border-bottom:1px solid #CCD3C8;padding:0 0 48px}section{padding:48px 0;border-bottom:1px solid #CCD3C8}h1{font-size:clamp(40px,6vw,72px);max-width:850px}h2{font-size:36px}h3{font-size:24px}.eyebrow{font-size:14px;letter-spacing:.12em;font-weight:600}.intro{max-width:780px;font-size:22px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:24px}.card{padding:24px;background:#FFF;border:1px solid #DDE5D7;border-radius:12px}.logo{width:100%;height:110px;object-fit:contain}.checker{background-color:#fff;background-image:linear-gradient(45deg,#e5e5e5 25%,transparent 25%),linear-gradient(-45deg,#e5e5e5 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#e5e5e5 75%),linear-gradient(-45deg,transparent 75%,#e5e5e5 75%);background-size:16px 16px;background-position:0 0,0 8px,8px -8px,-8px 0}.proof{display:flex;gap:28px;align-items:center;flex-wrap:wrap;padding:24px}.proof figure{margin:0;text-align:center}.proof img{display:block;margin:0 auto 12px;image-rendering:auto}.dark{background:#163E2D;color:#FAF7EF}.dark h3{color:inherit}.swatch{height:90px;border-radius:8px;border:1px solid #DDE5D7}table{width:100%;border-collapse:collapse;text-align:left;font-size:16px}td,th{padding:12px;border-bottom:1px solid #DDE5D7;vertical-align:top}code,pre{font-size:14px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#FFF;padding:24px;border:1px solid #DDE5D7}a{color:inherit;text-underline-offset:3px}.note{border-left:3px solid #86613B;padding-left:20px}.kn-display{font:500 36px/1.6 var(--display-kn)}.specimen{font:500 48px/1.2 var(--display);margin:20px 0}.nav{display:flex;gap:24px;flex-wrap:wrap}input{width:100%;min-height:48px;border:1px solid #163E2D;border-radius:8px;padding:12px;background:#fff}label{display:block;margin-bottom:8px}figcaption{font-size:14px}.badge{display:inline-block;background:#DDE5D7;padding:4px 12px;border-radius:20px;font-size:14px}@media(max-width:600px){main{padding:28px 20px}section{padding:32px 0}table{font-size:14px}td,th{padding:8px}.specimen{font-size:36px}}@media print{main{padding:20px}section{break-inside:avoid}button{display:none}}
</style><main><header><div class="eyebrow">AROHA RETREAT / BRAND STANDARDS / V2.0</div><h1>A quieter identity.<br>Clear at every size.</h1><p class="intro">A practical identity system for nature, meditation and farm life. One recognisable emblem, distinct language editions, transparent icon artwork, and typography chosen for reading and interaction.</p><nav class="nav" aria-label="Guide sections"><a href="#assets">Choose a logo</a><a href="#icons">Icons & favicons</a><a href="#type">Typography</a><a href="#digital">Implementation</a><a href="#sources">Sources</a></nav></header>
<section id="assets"><div class="eyebrow">01 / IDENTITY</div><h2>The right amount of identity</h2><div class="grid">'''+cards+'''</div><p class="note">The supplied Kannada name and tagline remain fixed outlined artwork. Latin AROHA now uses Lora 600; RETREAT and English supporting lines use Source Sans 3. The font families for supporting Kannada content are Noto Serif Kannada and Noto Sans Kannada. Do not retype the Kannada brand name as a substitute for the supplied logo.</p><table><tr><th>Use</th><th>Asset</th><th>Starting minimum</th></tr><tr><td>Browser tab</td><td>Micro mark only</td><td>16–32 px; actual-size proofs below</td></tr><tr><td>Toolbar / avatar / app</td><td>Full symbol only</td><td>48 px; micro at smaller sizes</td></tr><tr><td>Website navigation</td><td>Horizontal language logo</td><td>280 px wide, 55 mm print</td></tr><tr><td>Compact branding</td><td>Wordmark</td><td>240 px wide, 45 mm print</td></tr><tr><td>Signage / brochures</td><td>Primary or full</td><td>Primary 320 px / 60 mm; full 640 px / 110 mm</td></tr></table><p>These are conservative working recommendations, not manufacturing tolerances. Allow one head-diameter of clear space around a full emblem or lockup. For wordmarks allow half the A cap-height. Check actual material, viewing distance and the smallest counters before production.</p></section>
<section id="icons"><div class="eyebrow">02 / RESPONSIVE SYMBOL</div><h2>Icons are artwork, not miniature posters</h2><p>The full emblem keeps the inner heart, leaf and ground swoosh. The micro mark retains the head and seated heart-shaped silhouette, removing thin details that collapse at favicon size. Both contain no lettering. All icon PNG, WebP, TIFF, ICO and SVG artwork has transparent negative space; checkerboards are preview surfaces only.</p><div class="grid"><article class="card"><h3>Micro / actual pixels</h3><div class="proof checker">'''+''.join(f'<figure><img src="../02-icons/micro/aroha-icon-forest-{s}.png" width="{s}" height="{s}" alt="Micro mark at {s} pixels"><figcaption>{s} px</figcaption></figure>' for s in [16,24,32,48])+'''</div></article><article class="card dark"><h3>Reversed on dark</h3><div class="proof">'''+''.join(f'<figure><img src="../02-icons/micro/aroha-icon-white-{s}.png" width="{s}" height="{s}" alt="White micro mark at {s} pixels"><figcaption>{s} px</figcaption></figure>' for s in [16,24,32,48])+'''</div></article></div><div class="grid" style="margin-top:24px"><article class="card checker"><img src="../02-icons/full/aroha-icon-colour.svg" width="160" height="160" alt="Full transparent emblem"></article><article class="card"><h3>Optical rules</h3><p>64-unit square master; full mark fits a 56-unit keyline. Micro uses the same optical width with stronger perceived detail. Do not add inner shadows, gradients or outlines. Use forest on light surfaces and white on dark ones.</p></article><article class="card"><h3>Material principles</h3><p>Simple silhouettes, consistent proportions and separate brand and action icons. Use Material Symbols for actions such as search, calendar and directions; the Aroha mark identifies the retreat, not a button action.</p></article></div></section>
<section id="type"><div class="eyebrow">03 / TYPOGRAPHY</div><h2>Warm display. Clear interaction.</h2><div class="grid"><article class="card"><span class="badge">Lora 500 / 600</span><p class="specimen">Return to Yourself</p><p>Calligraphic curves and moderate contrast give editorial headings a calm, cultivated voice. Use for display, headings and the English brand name. Avoid long all-caps passages and tiny serif labels.</p></article><article class="card"><span class="badge">Source Sans 3 / 400 / 600</span><p style="font-size:24px">Find a slower rhythm.</p><p>Humanist sans serif for body copy, navigation, dates, prices, forms and buttons. Its interface purpose makes the text easier to scan than a decorative nature font.</p><button type="button">Explore the retreat</button></article><article class="card"><span class="badge">Kannada companion pair</span><p lang="kn" class="kn-display">ನಿಮ್ಮೊಳಗೆ ಮರಳಿ</p><p lang="kn">ಪ್ರಕೃತಿ ಮತ್ತು ಶಾಂತಿ</p><p>Noto Serif Kannada 500 for editorial headings; Noto Sans Kannada 400/600 for reading and controls. Never add letter spacing to Kannada. Allow at least 1.5 line height for Kannada headings and 1.65 for body text.</p></article></div><table><tr><th>Role</th><th>Family / weight</th><th>Size / line height</th><th>Use</th></tr>'''+''.join(f'<tr><td>{role}</td><td>{"Lora" if role in ["display","h1","h2","h3"] else "Source Sans 3"} / {v["weight"]}</td><td>{v["size"]} / {v["line"]} px</td><td>{"Editorial hierarchy" if role in ["display","h1","h2","h3"] else "Reading and interaction"}</td></tr>' for role,v in tokens['type'].items())+'''</table><p>At mobile widths, use 40/48 for display headings. Body text stays 18/28; controls at least 16/24. Use sentence case, a maximum reading measure around 65 characters, and no condensed Kannada. Font files, variable WOFF2, static TTF instances and each original OFL licence are bundled in 04-typography.</p></section>
<section><div class="eyebrow">04 / COLOUR & INTERACTION</div><h2>Nature is the tone, not the decoration</h2><div class="grid">'''+''.join(f'<article><div class="swatch" style="background:{color}"></div><p><strong>{name}</strong><br>{color}</p></article>' for name,color in [('Forest',G),('Leaf',L),('Bronze',B),('Ivory',I),('Mist',M)])+'''</div><p>Forest carries text and primary controls. Ivory is the main surface. Leaf is an accent for nature cues; bronze adds warmth to separators and large display details. Do not use leaf for small text on ivory. Verify contrast in the final colour pair: at least 4.5:1 for normal text and 3:1 for large text and meaningful non-text controls.</p><div class="grid"><article class="card"><h3>A considered interaction</h3><label for="sample-email">Email address</label><input id="sample-email" type="email" placeholder="you@example.com" autocomplete="email"><p class="body-small">Use a persistent label and clear input states.</p><button type="button">Plan a visit</button> <button type="button" disabled>Unavailable</button></article><article class="card"><h3>Behaviour</h3><p>48 px minimum targets; 8 px control radius; 4 px spacing base. Visible 3 px focus rings with 4 px offset. Keep controls readable under zoom and keyboard navigation. Use 180 ms colour transitions and respect reduced motion. Explain errors in text, not just colour.</p></article></div><p>No leaf textures, scripted body fonts or ornamental vines are needed. Use real retreat photography with quiet compositions when imagery helps someone choose an experience.</p></section>
<section id="digital"><div class="eyebrow">05 / DEPLOYMENT</div><h2>Transparent artwork. Explicit platform layers.</h2><table><tr><th>Surface</th><th>Files</th><th>Integration</th></tr><tr><td>Browser / Google Search</td><td>03-digital/web/favicon.ico, favicon-adaptive.svg, favicon-96.png</td><td>Copy web contents to /brand/ and apply head-snippet.html. Keep URLs stable and crawlable.</td></tr><tr><td>Web app / touch icon</td><td>icon-180.png, icon-192.png, icon-512.png, site.webmanifest</td><td>Transparent artwork, purpose any. Do not declare it maskable; some launchers add their own background.</td></tr><tr><td>Android adaptive</td><td>03-digital/android/res and transparent foreground/monochrome layers</td><td>108dp layers with 56dp-wide art inside the 66dp safe region. Background is a separate resource. Add AndroidManifest icon reference.</td></tr><tr><td>Social profile</td><td>03-digital/social/avatar-transparent-400/800/1024.png</td><td>Transparent source; the service may flatten or crop it. Inspect the circular crop.</td></tr><tr><td>Google Play / native iOS store</td><td>Use provided transparent artwork as input</td><td>No opaque store icon is claimed. Google Play expects a square 512px sRGB PNG with platform-applied corners; create a platform-specific background composite separately.</td></tr></table><p class="note">Transparent artwork and an opaque platform launcher are different deliverables. The download contains no opaque icon bitmaps. Android's background colour is supplied separately; it does not modify the foreground image. The manifest page background is also separate from icon transparency.</p><pre>'''+(OUT/WEB/'head-snippet.html').read_text().replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')+'''</pre><p>Open this guide locally, or serve the package with <code>python3 -m http.server 8080</code> and navigate to <code>/00-start-here/Brand-Standards.html</code>. This is a design preview; controls do not make bookings.</p></section>
<section><div class="eyebrow">06 / PRINT & GOVERNANCE</div><h2>A clear production handoff</h2><p>Use SVG for editable vectors and web. Use RGB PDF for general exchange; generic CMYK PDF/EPS in 05-print require press-profile conversion and a physical proof. TIFF masters have alpha and 300dpi metadata; resolution still depends on placement size. No spot-colour, PDF/X, native AI/CDR or trademark clearance is claimed.</p><p>Do not stretch the symbol, change its relative parts, place the white version on pale surfaces, retype the Kannada brand name, add effects, or use the detailed logo at favicon sizes. For engraving and embroidery, use the monochrome master and approve the smallest gaps with the fabricator.</p><p>V2 supersedes the v1 asset package. V1 remains the source reference only. The English wordmarks and supporting Latin text have been professionally typeset; Kannada fixed artwork has been preserved. Use only v2 files together.</p><p>See Asset-Map.csv for a use-by-use inventory, manifest.json for exact files and hashes, and Audit-Report.json for mechanical checks. Browser/launcher/device acceptance remains a separate production integration check.</p></section>
<section id="sources"><div class="eyebrow">07 / REFERENCE</div><h2>Sources & design decisions</h2><p>Checked 31 October 2026. Material-informed design, not Google endorsement or certification. Material's product icon guidance is historical; current Android and Search documentation governs the export details.</p><ol>'''+''.join(f'<li><a href="{url}">{title}</a> — {note}</li>' for title,url,note in sources)+'''</ol></section></main></html>'''
save(Path('00-start-here/Brand-Standards.html'),html)

# PDF handbook uses the selected fonts, not generic document defaults.
guide=OUT/'00-start-here/Aroha-Brand-Standards-v2.pdf';c=canvas.Canvas(str(guide),pagesize=(842,595));c.setTitle('Aroha Retreat / Brand Standards / v2.0')
def page(n,title,sub):
    c.setFillColor(HexColor('#FFFFFF'));c.rect(0,0,842,595,fill=1,stroke=0);c.setFillColor(HexColor(G));c.setFont('SourceSans3-600',10);c.drawString(44,555,'AROHA RETREAT  /  BRAND STANDARDS  /  V2.0')
    c.setFont('Lora-500',30);c.drawString(44,500,title);c.setFont('SourceSans3-400',12);c.drawString(44,475,sub)
    c.setStrokeColor(HexColor('#CCD3C8'));c.line(44,40,798,40);c.setFont('SourceSans3-400',9);c.drawString(44,24,'31 OCTOBER 2026  /  TRANSPARENT ARTWORK SYSTEM');c.drawRightString(798,24,f'{n:02d}')
def para(x,y,lines,size=12,lead=19,weight=400):
    c.setFillColor(HexColor(G));c.setFont(f'SourceSans3-{weight}',size)
    for line in lines:c.drawString(x,y,line);y-=lead
def draw(node,x,y,w):
    d=svg2rlg(io.BytesIO(xml(node)));sc=w/d.width;d.scale(sc,sc);renderPDF.draw(d,c,x,y)
def end():c.showPage()
page(1,'A quieter identity. Clear at every size.','Nature, meditation and farm life, expressed as a coherent visual system.')
draw(logo('english','primary'),80,85,390);para(490,350,['One emblem. Three language editions.','A responsive full and micro icon system.','All standalone icons remain transparent.','', 'Warm editorial type, legible interfaces,','clear production rules and source files.','', 'Start with the HTML guide for actual-size','favicon proofs, CSS and live font samples.'],13,23);end()
page(2,'Choose the right lockup','English, Kannada and bilingual sets each include four layouts and four colour versions.')
for i,lang in enumerate(['english','kannada','bilingual']):
    x=44+i*255;draw(logo(lang,'primary'),x,200,235);para(x,175,[lang.upper(),'Full / primary / horizontal / wordmark','Colour / forest / black / white'],10,18)
para(44,95,['Horizontal logos are for website headers. Wordmarks omit the emblem.','Primary omits supporting lines. Full is for spacious editorial and print placements.']);end()
page(3,'Transparent icon family','Brand identification stays independent of language and typography.')
draw(icon('full'),100,230,160);draw(icon('micro'),405,230,160)
para(85,200,['FULL EMBLEM / 48 px and above','Inner heart, leaf and ground swoosh.','Use for app artwork and avatars.'])
para(405,200,['MICRO MARK / 16-32 px','Head and seated heart silhouette.','Thin secondary details are removed.'])
para(44,100,['Every SVG, PNG, WebP, TIFF and ICO icon has transparent negative space.','Forest, black and white icon masters are supplied. Preview surfaces are not baked into artwork.']);end()
page(4,'Keylines & small-size behaviour','Derived from Material principles; the Aroha emblem remains the brand asset.')
c.setStrokeColor(HexColor('#CCD3C8'))
for x in range(65,322,32):c.line(x,170,x,426)
for y in range(170,427,32):c.line(65,y,321,y)
draw(icon('micro'),65,170,256)
para(370,410,['SQUARE MASTER / 64 units','Visible micro artwork fits 56 units across.','Keep the head optically centred over the body.','Do not add a surrounding badge to the master.','', 'FAVICON / 16, 24, 32 px','Use the micro silhouette. Review at 100% scale.','Use forest on light chrome and white on dark.','The adaptive SVG responds to the colour scheme.','', 'See the HTML guide for actual pixel-sized proofs.']);end()
page(5,'Spacing & usage sizes','Starting recommendations, to be checked against viewing distance and material.')
draw(logo('english','horizontal'),60,265,580)
para(44,235,['Full lockup: 640 px / 110 mm. Primary: 320 px / 60 mm.','Horizontal: 280 px / 55 mm. Wordmark: 240 px / 45 mm.','Full symbol: 48 px / 12 mm. Micro: 16-32 px, screen only.','', 'Full emblem / logo clear space: at least one head-diameter outside visible art.','Wordmark clear space: at least half the English A cap-height.','No stretching, arbitrary colours, rotation, effects or busy photo backgrounds.','Embroidery and engraving need a fabricator proof of the narrowest internal gaps.']);end()
page(6,'Typography with a purpose','Four script-specific families form two roles: editorial display and readable interaction.')
c.setFont('Lora-500',36);c.drawString(44,415,'Return to Yourself')
para(44,375,['LORA / 500 and 600','Calligraphic curves and moderate contrast give headings a warm editorial voice.','Use for English display, headings and AROHA. Keep it out of small control labels.','', 'SOURCE SANS 3 / 400 and 600','A humanist sans designed for interfaces. Use for reading, navigation, dates, forms and buttons.','RETREAT and English supporting lines use this family.','', 'NOTO SERIF KANNADA / 500  +  NOTO SANS KANNADA / 400 and 600','Serif for Kannada editorial headings; sans for reading and interaction. No Kannada tracking.','The supplied Kannada logo lettering remains fixed outlined artwork, not substituted live type.']);end()
page(7,'Type scale & bilingual rhythm','Use the same hierarchy across scripts while allowing Kannada its own vertical space.')
yy=425
for role,v in tokens['type'].items():
    para(44,yy,[f'{role.upper():12s}   {v["size"]}/{v["line"]} px   /   weight {v["weight"]}'],13);yy-=30
sample=root(720,100,'Kannada typography specimen');text(sample,'ನಿಮ್ಮೊಳಗೆ ಮರಳಿ',350,60,40,'NotoSerifKannada',500);draw(sample,44,85,520)
para(44,65,['Kannada headings: line height at least 1.5; body 1.65. Mobile display 40/48; controls at least 16/24.'],10);end()
page(8,'Colour & accessible interaction','Forest leads; leaf and bronze are accents, with ivory and mist as quiet surfaces.')
for i,(name,hx) in enumerate([('Forest',G),('Leaf',L),('Bronze',B),('Ivory',I),('Mist',M)]):
    x=44+i*151;c.setFillColor(HexColor(hx));c.setStrokeColor(HexColor('#CCD3C8'));c.rect(x,290,133,130,fill=1,stroke=1)
    cs=colour_spec(hx);para(x,270,[name,hx,'RGB '+' / '.join(map(str,cs['rgb'])),'CMYK '+' / '.join(map(str,cs['genericCmykPercent']))],10,18)
para(44,190,['Use forest for small text and primary actions. Leaf is not approved for small text on ivory.','Aim for 4.5:1 normal text and 3:1 large text / meaningful control boundaries.','48 px minimum targets. 3 px focus ring with 4 px offset. Persistent field labels.','4 px spacing base; 8 px control corners. Error states use text as well as colour.','180 ms subtle colour changes; respect reduced motion.']);end()
page(9,'Digital implementation','Ready-to-copy web files and separate Android resources are included.')
para(44,425,['BROWSER / SEARCH','03-digital/web: favicon.ico, favicon-adaptive.svg, favicon-96.png and head-snippet.html.','Use stable, crawlable URLs. Search visibility is not guaranteed by having a file.','', 'WEB APP / TOUCH','Transparent 180, 192 and 512 px icons. Web manifest icons use purpose any, not maskable.','Launchers can add their own surfaces. Validate on the actual target devices.','', 'ANDROID ADAPTIVE','Foreground and monochrome artwork are 108dp layers; logo content stays inside the safe region.','res/ includes drawable vectors, v26/v33 adaptive XML and a separate background colour.','Add android:icon="@mipmap/ic_launcher" to the application manifest.','', 'STORE SUBMISSIONS','No opaque store icon is included. Create a dedicated platform composite from transparent art.'],12,21);end()
page(10,'Print, fonts & production handoff','Use the package source of truth and keep production acceptance explicit.')
para(44,425,['SVG / PDF / EPS: outlined vectors. No fonts or linked bitmaps are needed to render a logo.','PNG / WebP / TIFF: transparent raster artwork. TIFF includes 300 dpi metadata.','05-print: generic CMYK conversions, no press ICC profile or PDF/X certification.','', 'Font bundle: original variable TTF and WOFF2, plus static 400 / 500 / 600 print instances.','Every original SIL Open Font License is included beside its family. Keep those files with redistribution.','The English wordmarks are Lora 600; the Kannada brand name is original outlined lettering.','', 'No native AI/CDR/PSD files, spot-ink matching, trademark clearance or store submission is claimed.','For print, convert with the actual press/paper ICC profile and approve a physical proof.','For native launchers and store artwork, validate in the platform toolchain before publishing.','', 'V2 supersedes V1. Do not mix wordmark typography or favicon assets between versions.']);end()
page(11,'Sources & reference boundaries','Checked 31 October 2026. Material-informed; no affiliation or Google certification.')
yy=425
for title,url,note in sources:
    c.setFont('SourceSans3-600',11);c.setFillColor(HexColor(G));c.drawString(44,yy,title);c.linkURL(url,(44,yy-3,798,yy+13),relative=0)
    c.setFont('SourceSans3-400',10);c.drawString(44,yy-15,note[:133]);yy-=30
para(44,65,['Clickable reference titles link to the official sources. Full URLs and notes are in Sources.md and the HTML guide.'],10);end();c.save()

save(Path('07-source/original-trace.svg'),(a.input/'source/trace.svg').read_bytes());save(Path('07-source/original-reference.png'),(a.input/'source/reference.png').read_bytes())
save(Path('07-source/build_brand_system.py'),Path(__file__).read_bytes())
save(Path('07-source/requirements.txt'),'pillow\ncairosvg\nsvglib\nreportlab\nfonttools[woff]\nuharfbuzz\npymupdf\n')
save(Path('07-source/BUILD.md'),'''# Rebuild
Install requirements.txt. This script requires the system Cairo library for CairoSVG.
Make an input folder containing source/trace.svg, source/reference.png and fonts/<Family>/.
Use original-trace.svg and original-reference.png for the source files.
Copy 04-typography/fonts into the input fonts/ directory.
Run python build_brand_system.py --input INPUT --output NEW_OUTPUT.
Do not build over a modified release folder. Output is deterministic in geometry; PDF metadata can vary.
''')
save(Path('README.txt'),'''AROHA RETREAT / BRAND SYSTEM V2

START: 00-start-here/Brand-Standards.html or Aroha-Brand-Standards-v2.pdf.
FAVICON: 03-digital/web/favicon.ico + favicon-adaptive.svg + favicon-96.png.
ICON ONLY: 02-icons/full/ (48px+) and 02-icons/micro/ (16-32px).
LANGUAGES: 01-logos/english, kannada, bilingual.
LAYOUTS: full, primary, horizontal, wordmark. Four colour modes each.
All icon artwork has transparent negative space. No opaque icon bitmap is included.
White variants need a dark preview surface. Do not use a detailed full logo as a favicon.
TYPOGRAPHY: Lora, Source Sans 3, Noto Serif Kannada, Noto Sans Kannada.
Font files, webfonts, licences, CSS and design tokens are bundled.
Android background is an independent optional platform resource, separate from transparent art.
Generic CMYK files require printer colour management and a physical proof.
This v2 package supersedes v1. See the handbook for platform and native format limitations.
''')

# Add the executable nature motion library and append its PDF specification.
import importlib.util
module_spec=importlib.util.spec_from_file_location('nature_motion',Path(__file__).with_name('add_nature_motion.py'))
motion_module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(motion_module)
motion_module.build_motion(OUT)
save(Path('07-source/add_nature_motion.py'),Path(__file__).with_name('add_nature_motion.py').read_bytes())

# Exact file inventory and mechanical release audit.
with (OUT/'00-start-here/Asset-Map.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['path','kind','purpose','width','transparent']);writer.writeheader();writer.writerows(assets)
checks={'transparent_pngs':0,'transparent_webps':0,'transparent_tiffs':0,'icon_svg_square':0,'ico_frames':{},'font_families':4,'missing_glyphs':0,'language_layouts':12,'colour_modes':4}
for f in OUT.rglob('*'):
    if f.suffix.lower() in ['.png','.webp','.tiff'] and '07-source' not in f.parts:
        im=Image.open(f);assert im.mode=='RGBA',str(f)
        amin,amax=im.getchannel('A').getextrema()
        assert amin==0 and amax>=128,str(f)  # tiny antialiased shapes may have no fully opaque pixel
        key={'.png':'transparent_pngs','.webp':'transparent_webps','.tiff':'transparent_tiffs'}[f.suffix.lower()];checks[key]+=1
    if f.suffix=='.svg' and ('02-icons' in f.parts or '03-digital' in f.parts):
        node=ET.parse(f).getroot();vb=list(map(float,node.get('viewBox').split()));assert vb[2]==vb[3];assert not any(n.tag.endswith('rect') and n.get('fill') for n in node.iter());checks['icon_svg_square']+=1
    if f.suffix=='.ico':
        im=Image.open(f);checks['ico_frames'][str(f.relative_to(OUT))]=[list(s) for s in sorted(im.ico.sizes())];assert (16,16) in im.ico.sizes() and (32,32) in im.ico.sizes()
        for size in im.ico.sizes():assert im.ico.getimage(size).convert('RGBA').getchannel('A').getextrema()[0]==0
save(Path('00-start-here/Audit-Report.json'),json.dumps({'version':'2.0.0','checks':checks,'status':'mechanical checks passed','limits':['No Android build or physical launcher test','No store upload acceptance','Generic CMYK not press-profiled','Browser acceptance recorded separately']},indent=2))
inventory=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p!=OUT/'00-start-here/manifest.json':inventory.append({'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
save(Path('00-start-here/manifest.json'),json.dumps({'version':'2.0.0','files':inventory},indent=2))
with zipfile.ZipFile(OUT.parent/'Aroha-Retreat-Brand-System-v2.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file():z.write(p,Path(OUT.name)/p.relative_to(OUT))
print(json.dumps({'files':len(inventory)+1,'checks':checks,'guide':str(guide),'zip':str(OUT.parent/'Aroha-Retreat-Brand-System-v2.zip')},indent=2))
