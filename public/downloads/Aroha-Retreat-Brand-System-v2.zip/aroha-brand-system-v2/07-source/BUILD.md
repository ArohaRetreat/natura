# Rebuild
Install requirements.txt. This script requires the system Cairo library for CairoSVG.
Make an input folder containing source/trace.svg, source/reference.png and fonts/<Family>/.
Use original-trace.svg and original-reference.png for the source files.
Copy 04-typography/fonts into the input fonts/ directory.
Run python build_brand_system.py --input INPUT --output NEW_OUTPUT.
Do not build over a modified release folder. Output is deterministic in geometry; PDF metadata can vary.
